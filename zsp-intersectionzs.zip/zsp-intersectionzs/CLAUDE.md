ALWAYS use UV for python.
WHEN I ASK FOR WHY YOU DID A CERTAIN CODING PRACTICE OFFER TO ADD IN CLAUDE.md a modification to PREVENT it from happening further down the line.
DO NOT DUPLICATE CODE OR CREATE VARIANTS OF ALREADY IMPLEMENTED FUNCTIONS OR CLASSES
NEVER fail silently, or add UN-NEEDED fallbacks instead properly error-out.
MAKE the errors, exceptions and others clear and descriptive.
DO NOT over-complicate or over-engineer.
BE RIGOROUS.
CHECK AND TEST your work.
DO NOT be a YES-MAN and instead use critical thinking.
when making a plan make the tasks ATOMIC.
DO NOT make any assumptions or hypotheses, always ask for clarifications even for the smallest things if there are any "dark spots" or unknown data, modalities or if you aren't sure of the intent and goals.
STORE all log files in the logs/ directory to keep the project root clean.
DO NOT and I repeat, DO NOT use any cheap tricks like simplification, approximation or methods like these INSTEAD of doing the ACTUAL work.
NEVER make unverified quantitative claims - no performance numbers, percentages, memory savings, or speedup claims without actual measurement or solid evidence.
