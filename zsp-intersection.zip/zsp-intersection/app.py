#!/usr/bin/env python3

import json
import os

import folium
from flask import Flask, Response, jsonify, render_template, request

from zsp_checker import ZSPChecker

app = Flask(__name__)
app.config["TEMPLATES_AUTO_RELOAD"] = True

checker = ZSPChecker()

ZSP_COLORS = {
    "PN": "#E1000F",
    "GN": "#417DC4",
}


def create_base_map(
    center_lat: float = 46.603354, center_lon: float = 1.888334, zoom: int = 6
) -> folium.Map:
    """Create base map centered on France with ZSP zones."""
    m = folium.Map(
        location=[center_lat, center_lon],
        zoom_start=zoom,
        tiles="OpenStreetMap",
        prefer_canvas=True,
        width="100%",
        height="100%",
    )

    with open("secu_zsp_2018.json", encoding="utf-8") as f:
        geojson_data = json.load(f)

    folium.GeoJson(
        geojson_data,
        name="ZSP Zones",
        style_function=lambda feature: {
            "fillColor": ZSP_COLORS.get(
                feature["properties"].get("competence", "PN"), "#FF6B6B"
            ),
            "color": "black",
            "weight": 1,
            "fillOpacity": 0.4,
            "opacity": 0.7,
        },
        tooltip=folium.GeoJsonTooltip(
            fields=["nom_zsp", "competence", "departemen"],
            aliases=["Zone:", "Competence:", "Department:"],
            localize=True,
            sticky=False,
            labels=True,
            style="""
                background-color: white;
                border: 2px solid black;
                border-radius: 3px;
                box-shadow: 3px;
            """,
        ),
        highlight_function=lambda _: {"weight": 3, "fillOpacity": 0.7},
    ).add_to(m)

    folium.LayerControl().add_to(m)

    legend_html = """
    <div style="position: fixed;
                bottom: 50px; right: 50px; width: 220px;
                background-color: white; z-index: 1000; font-size: 14px;
                border: 1px solid #CECECE; box-shadow: 0 2px 6px rgba(0,0,0,0.1); padding: 16px;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Arial, sans-serif;">
        <p style="margin: 0; padding: 0 0 12px 0; font-weight: 700; color: #3A3A3A;
                  border-bottom: 1px solid #CECECE; font-size: 16px;">
            Zones de Sécurité Prioritaires
        </p>
        <p style="margin: 0; padding: 8px 0 4px 0; display: flex; align-items: center;">
            <span style="background-color: #E1000F; width: 20px; height: 20px;
                  display: inline-block; margin-right: 8px; opacity: 0.8;"></span>
            <span style="color: #666666; font-size: 14px;">Police Nationale (PN)</span>
        </p>
        <p style="margin: 0; padding: 4px 0; display: flex; align-items: center;">
            <span style="background-color: #417DC4; width: 20px; height: 20px;
                  display: inline-block; margin-right: 8px; opacity: 0.8;"></span>
            <span style="color: #666666; font-size: 14px;">Gendarmerie (GN)</span>
        </p>
    </div>
    """
    m.get_root().html.add_child(folium.Element(legend_html))

    return m


def add_marker_to_map(
    m: folium.Map,
    lat: float,
    lon: float,
    address: str,
    in_zsp: bool,
    zone_info: dict[str, str] | None = None,
) -> folium.Map:
    """Add a marker for the searched address."""
    if in_zsp and zone_info:
        color = "red"
        icon = "exclamation-triangle"
        popup_html = f"""
        <div style="font-family: Arial; width: 250px;">
            <h4 style="color: red;">⚠️ In ZSP Zone</h4>
            <p><b>Address:</b> {address}</p>
            <p><b>Zone:</b> {zone_info['name']}</p>
            <p><b>Department:</b> {zone_info['department']}</p>
            <p><b>Competence:</b> {zone_info['competence']}</p>
            <p><b>Coordinates:</b> {lat:.6f}, {lon:.6f}</p>
        </div>
        """
    else:
        color = "green"
        icon = "check"
        popup_html = f"""
        <div style="font-family: Arial; width: 250px;">
            <h4 style="color: green;">✓ Not in ZSP Zone</h4>
            <p><b>Address:</b> {address}</p>
            <p><b>Coordinates:</b> {lat:.6f}, {lon:.6f}</p>
        </div>
        """

    folium.Marker(
        location=[lat, lon],
        popup=folium.Popup(popup_html, max_width=300),
        tooltip=address,
        icon=folium.Icon(color=color, icon=icon, prefix="fa"),
    ).add_to(m)

    return m


@app.route("/")
def index() -> str:
    """Main page with map and search form."""
    m = create_base_map()
    map_html = m._repr_html_()

    return render_template("index.html", map_html=map_html)


@app.route("/check_address", methods=["POST"])
def check_address() -> Response | tuple[Response, int]:
    """API endpoint to check an address and return map with marker."""
    address = request.form.get("address", "").strip()

    if not address:
        return jsonify({"error": "Please provide an address"}), 400

    result = checker.check_address(address)

    if not result["success"] or not result["coordinates"] or result["in_zsp"] is None:
        return jsonify({"error": result.get("error", "Could not process address")}), 400

    lat = result["coordinates"]["lat"]
    lon = result["coordinates"]["lon"]
    m = create_base_map(center_lat=lat, center_lon=lon, zoom=14)

    zone_info_dict: dict[str, str] | None = None
    if result["in_zsp"] and result["zones"]:
        zone_info = result["zones"][0]
        zone_info_dict = {
            "id": zone_info["id"],
            "name": zone_info["name"],
            "competence": zone_info["competence"],
            "department": zone_info["department"],
        }

    m = add_marker_to_map(m, lat, lon, address, result["in_zsp"], zone_info_dict)

    response = {
        "map_html": m._repr_html_(),
        "address": address,
        "coordinates": result["coordinates"],
        "in_zsp": result["in_zsp"],
        "zones": result.get("zones", []),
    }

    return jsonify(response)


@app.route("/api/zones")
def get_zones() -> Response:
    """API endpoint to get all ZSP zones information."""
    zones_info = []
    for zone in checker.zones:
        zones_info.append(
            {
                "id": zone["id"],
                "name": zone["name"],
                "department": zone["department"],
                "competence": zone["competence"],
            }
        )

    return jsonify({"total": len(zones_info), "zones": zones_info})


if __name__ == "__main__":
    import socket
    import sys

    os.makedirs("templates", exist_ok=True)

    # Parse command line arguments for port and host
    host = "0.0.0.0"  # Listen on all interfaces for remote access
    port = 5000

    if len(sys.argv) > 1:
        port = int(sys.argv[1])
    if len(sys.argv) > 2:
        host = sys.argv[2]

    # Get the server's IP addresses
    hostname = socket.gethostname()
    local_ip = socket.gethostbyname(hostname)

    print("=" * 60)
    print(" ZSP Map GUI Starting")
    print("=" * 60)
    print(f"Loaded {len(checker.zones)} ZSP zones")
    print("\nServer is accessible at:")
    print(f"  Local:    http://localhost:{port}")
    print(f"  Network:  http://{local_ip}:{port}")

    # If running on JupyterHub, show proxy URL
    if os.environ.get("JUPYTERHUB_SERVICE_PREFIX"):
        prefix = os.environ.get("JUPYTERHUB_SERVICE_PREFIX")
        print(f"  JupyterHub: {prefix}proxy/{port}/")

    print("\nPress Ctrl+C to stop the server")
    print("-" * 60)

    app.run(debug=False, host=host, port=port)
