#!/usr/bin/env python3

import json
import os
import sys
import time
from typing import TypedDict

import requests
from shapely.geometry import Point, shape
from shapely.geometry.base import BaseGeometry


class ZoneInfo(TypedDict):
    id: str
    name: str
    competence: str
    department: str


class ZoneData(TypedDict):
    geometry: BaseGeometry
    id: str | None
    name: str | None
    competence: str | None
    department: str | None


class CheckResult(TypedDict):
    success: bool
    address: str
    error: str | None
    coordinates: dict[str, float] | None
    in_zsp: bool | None
    zones: list[ZoneInfo] | None


class ZSPChecker:
    """Class to check if addresses fall within ZSP zones."""

    def __init__(self, geojson_file: str = "secu_zsp_2018.json"):
        """
        Initialize the ZSP checker with GeoJSON data.

        Args:
            geojson_file: Path to the GeoJSON file containing ZSP boundaries
        """
        self.zones: list[ZoneData] = []
        self.load_zones(geojson_file)

    def load_zones(self, geojson_file: str) -> None:
        """Load ZSP zones from GeoJSON file."""
        try:
            with open(geojson_file, encoding="utf-8") as f:
                data = json.load(f)

            for feature in data["features"]:
                geometry = shape(feature["geometry"])
                properties = feature["properties"]

                self.zones.append(
                    {
                        "geometry": geometry,
                        "id": properties.get("id_zsp"),
                        "name": properties.get("nom_zsp"),
                        "competence": properties.get("competence"),
                        "department": properties.get("departemen"),
                    }
                )

            if os.environ.get("WERKZEUG_RUN_MAIN") == "true":
                print(f"Loaded {len(self.zones)} ZSP zones")

        except FileNotFoundError:
            raise FileNotFoundError(
                f"Could not find GeoJSON file: {geojson_file}"
            ) from None
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON in file: {e}") from e

    def geocode_address(self, address: str) -> tuple[float, float] | None:
        """
        Geocode an address using Nominatim API (OpenStreetMap).

        Args:
            address: The address to geocode

        Returns:
            Tuple of (latitude, longitude) or None if geocoding fails
        """
        base_url = "https://nominatim.openstreetmap.org/search"

        if "france" not in address.lower():
            address += ", France"

        params: dict[str, str | int] = {
            "q": address,
            "format": "json",
            "limit": 1,
            "countrycodes": "fr",
        }

        headers = {"User-Agent": "ZSP-Checker/1.0 (checking security zones)"}

        try:
            response = requests.get(
                base_url, params=params, headers=headers, timeout=10
            )
            response.raise_for_status()

            data = response.json()

            if data:
                lat = float(data[0]["lat"])
                lon = float(data[0]["lon"])
                display_name = data[0].get("display_name", "")

                print(f"Geocoded address: {display_name}")
                print(f"Coordinates: {lat}, {lon}")

                return (lat, lon)
            else:
                print(f"Could not geocode address: {address}")
                return None

        except requests.exceptions.RequestException as e:
            print(f"Error geocoding address: {e}")
            return None
        except (KeyError, ValueError, IndexError) as e:
            print(f"Error parsing geocoding response: {e}")
            return None

    def check_point_in_zones(self, lat: float, lon: float) -> list[ZoneInfo]:
        """
        Check if a point (lat, lon) falls within any ZSP zone.

        Args:
            lat: Latitude
            lon: Longitude

        Returns:
            List of ZSP zones that contain the point
        """
        point = Point(lon, lat)  # Shapely uses (lon, lat) order
        matching_zones = []

        for zone in self.zones:
            geometry = zone["geometry"]

            if geometry.contains(point):
                matching_zones.append(
                    ZoneInfo(
                        id=zone["id"] or "",
                        name=zone["name"] or "",
                        competence=zone["competence"] or "",
                        department=zone["department"] or "",
                    )
                )

        return matching_zones

    def check_address(self, address: str) -> CheckResult:
        """
        Check if an address falls within any ZSP zone.

        Args:
            address: The address to check

        Returns:
            Dictionary with results
        """
        print(f"\nChecking address: {address}")
        print("-" * 50)

        coords = self.geocode_address(address)

        if coords is None:
            return CheckResult(
                success=False,
                error="Could not geocode address",
                address=address,
                coordinates=None,
                in_zsp=None,
                zones=None,
            )

        lat, lon = coords

        matching_zones = self.check_point_in_zones(lat, lon)

        result = CheckResult(
            success=True,
            address=address,
            coordinates={"lat": lat, "lon": lon},
            in_zsp=len(matching_zones) > 0,
            zones=matching_zones,
            error=None,
        )

        print("\nRESULTS:")
        print("-" * 50)
        if result["in_zsp"]:
            print("✗ This address IS IN a Security Priority Zone (ZSP)")
            for zone in matching_zones:
                print(f"  - Zone: {zone['name']}")
                print(f"    ID: {zone['id']}")
                print(f"    Department: {zone['department']}")
                print(
                    f"    Competence: {zone['competence']} {'(Police Nationale)' if zone['competence'] == 'PN' else '(Gendarmerie Nationale)'}"
                )
        else:
            print("✓ This address is NOT in a Security Priority Zone")

        return result


def main() -> None:
    """Main function for command-line usage."""
    if len(sys.argv) < 2:
        print('Usage: python zsp_checker.py "<address>"')
        print("\nExamples:")
        print('  python zsp_checker.py "15 rue de la République, Montpellier"')
        print('  python zsp_checker.py "Place de la Comédie, Béziers"')
        print('  python zsp_checker.py "10 rue Victor Hugo, Paris"')
        sys.exit(1)

    address = " ".join(sys.argv[1:])

    try:
        checker = ZSPChecker()
        checker.check_address(address)

        time.sleep(0.25)

    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
