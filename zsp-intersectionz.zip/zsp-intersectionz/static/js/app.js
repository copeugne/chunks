let searchHistory = [];
const maxHistory = 5;

document.getElementById('searchForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const address = document.getElementById('addressInput').value.trim();
    if (address) {
        searchAddress(address);
    }
});

// Client-side geocoding using Nominatim API
async function geocodeAddress(address) {
    console.log('[GEOCODE-API] Starting geocoding for:', address);

    // Add France to address if not already present
    let searchAddress = address;
    if (!address.toLowerCase().includes('france')) {
        searchAddress = address + ', France';
        console.log('[GEOCODE-API] Added "France" to address:', searchAddress);
    }

    const params = new URLSearchParams({
        q: searchAddress,
        format: 'json',
        limit: '1',
        countrycodes: 'fr'
    });

    const geocodeUrl = `https://nominatim.openstreetmap.org/search?${params}`;
    console.log('[GEOCODE-API] Request URL:', geocodeUrl);

    try {
        console.log('[GEOCODE-API] Sending request to Nominatim...');
        const response = await fetch(geocodeUrl, {
            headers: {
                'Accept': 'application/json'
            }
        });

        console.log('[GEOCODE-API] Response status:', response.status);

        if (!response.ok) {
            console.log('[GEOCODE-API] ❌ Request failed with status:', response.status);
            throw new Error('Geocoding API request failed');
        }

        const data = await response.json();
        console.log('[GEOCODE-API] Response data:', data);

        if (data && data.length > 0) {
            const result = data[0];
            console.log('[GEOCODE-API] ✅ Geocoding successful');
            console.log('[GEOCODE-API] Found location:', result.display_name);
            console.log('[GEOCODE-API] Coordinates:', result.lat, result.lon);
            return {
                lat: parseFloat(result.lat),
                lon: parseFloat(result.lon),
                display_name: result.display_name
            };
        } else {
            console.log('[GEOCODE-API] ⚠️ No results found for address');
            return null;
        }
    } catch (error) {
        console.log('[GEOCODE-API] ❌ Geocoding error:', error);
        console.error('Geocoding error details:', error);
        return null;
    }
}

// Helper function to get XSRF token from cookies (JupyterHub sets this)
function getXSRFToken() {
    console.log('[XSRF] Starting token extraction...');
    console.log('[XSRF] Raw cookies string:', document.cookie);

    const cookies = document.cookie.split(';');
    console.log('[XSRF] Split cookies into', cookies.length, 'parts');

    for (let i = 0; i < cookies.length; i++) {
        const cookie = cookies[i];
        console.log('[XSRF] Processing cookie', i, ':', cookie);

        const [name, value] = cookie.trim().split('=');
        console.log('[XSRF] Cookie name:', name, 'Value:', value ? value.substring(0, 20) + '...' : 'undefined');

        if (name === '_xsrf') {
            console.log('[XSRF] Found _xsrf cookie!');
            // The _xsrf cookie value is already URL-encoded, decode it
            const decodedValue = decodeURIComponent(value);
            console.log('[XSRF] Decoded token:', decodedValue.substring(0, 20) + '...');
            return decodedValue;
        }
    }

    console.log('[XSRF] No _xsrf cookie found in', cookies.length, 'cookies');
    return null;
}

async function searchAddress(address) {
    console.log('========================================');
    console.log('[SEARCH] Starting search for address:', address);
    console.log('[SEARCH] Current URL:', window.location.href);
    console.log('[SEARCH] Current origin:', window.location.origin);
    console.log('========================================');

    document.getElementById('addressInput').value = address;

    document.getElementById('loadingSpinner').classList.add('show');
    document.getElementById('resultCard').classList.remove('show');
    document.getElementById('errorMessage').style.display = 'none';

    // First try to geocode the address client-side
    console.log('[GEOCODE] Starting client-side geocoding for:', address);
    const geocodeResult = await geocodeAddress(address);

    // Prepare request data as JSON
    const requestData = {
        address: address
    };

    if (geocodeResult) {
        console.log('[GEOCODE] Success! Coordinates:', geocodeResult.lat, geocodeResult.lon);
        console.log('[GEOCODE] Display name:', geocodeResult.display_name);
        requestData.lat = geocodeResult.lat;
        requestData.lon = geocodeResult.lon;
    } else {
        console.log('[GEOCODE] Failed - will fallback to server-side geocoding');
    }

    // Get the XSRF token from JupyterHub cookie
    console.log('[TOKEN] Attempting to extract XSRF token...');
    const xsrfToken = getXSRFToken();

    // Log token status for debugging
    if (xsrfToken) {
        console.log('[TOKEN] ✅ XSRF token successfully extracted');
        console.log('[TOKEN] Token preview:', xsrfToken.substring(0, 20) + '...');
        console.log('[TOKEN] Token length:', xsrfToken.length);
    } else {
        console.log('[TOKEN] ⚠️ NO XSRF TOKEN FOUND');
        console.log('[TOKEN] This may cause 403 errors if running behind JupyterHub');
    }

    // Prepare headers with XSRF token if available
    const headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
    };

    // Add XSRF token to headers (JupyterHub expects this)
    if (xsrfToken) {
        headers['X-XSRFToken'] = xsrfToken;
        headers['X-CSRFToken'] = xsrfToken; // Some configurations use this header name
        // Also add to request body for JupyterHub compatibility
        requestData._xsrf = xsrfToken;
        console.log('[TOKEN] Added XSRF token to:');
        console.log('[TOKEN]   - X-XSRFToken header');
        console.log('[TOKEN]   - X-CSRFToken header');
        console.log('[TOKEN]   - Request body _xsrf field');
    }

    console.log('[REQUEST] Preparing POST to /check_address');
    console.log('[REQUEST] Headers:', JSON.stringify(headers, null, 2));
    console.log('[REQUEST] Body:', JSON.stringify(requestData, null, 2));

    // Try JSON request with XSRF token
    console.log('[REQUEST] Sending JSON POST request...');
    fetch('/check_address', {
        method: 'POST',
        headers: headers,
        credentials: 'same-origin',
        body: JSON.stringify(requestData)
    })
    .then(async response => {
        console.log('[RESPONSE] Status:', response.status, response.statusText);
        console.log('[RESPONSE] Headers:', response.headers);

        if (response.status === 403) {
            // CSRF error, try with form-encoded and XSRF token
            console.log('[RESPONSE] ❌ 403 Forbidden - CSRF token issue detected');
            console.log('[FALLBACK] Attempting form-encoded request with XSRF token...');
            console.log('[FALLBACK] XSRF token status:', xsrfToken ? '✅ Available' : '⚠️ Missing');

            // Try to read error message if available
            try {
                const errorText = await response.text();
                console.log('[RESPONSE] 403 Error message:', errorText);
            } catch (e) {
                console.log('[RESPONSE] Could not read error text');
            }

            let body = 'address=' + encodeURIComponent(address);
            if (geocodeResult) {
                body += '&lat=' + encodeURIComponent(geocodeResult.lat);
                body += '&lon=' + encodeURIComponent(geocodeResult.lon);
            }

            // Add XSRF token if available (already extracted above)
            if (xsrfToken) {
                body += '&_xsrf=' + encodeURIComponent(xsrfToken);
                console.log('[FALLBACK] Added _xsrf to form body');
            }

            const fallbackHeaders = {
                'Content-Type': 'application/x-www-form-urlencoded',
            };

            // Also add token to headers for fallback request
            if (xsrfToken) {
                fallbackHeaders['X-XSRFToken'] = xsrfToken;
                fallbackHeaders['X-CSRFToken'] = xsrfToken;
                console.log('[FALLBACK] Added XSRF token to fallback headers');
            }

            console.log('[FALLBACK] Form body:', body);
            console.log('[FALLBACK] Fallback headers:', JSON.stringify(fallbackHeaders, null, 2));
            console.log('[FALLBACK] Sending form-encoded POST request...');

            return fetch('/check_address', {
                method: 'POST',
                headers: fallbackHeaders,
                credentials: 'same-origin',
                body: body
            });
        } else if (response.status === 200) {
            console.log('[RESPONSE] ✅ 200 OK - Request successful');
        } else {
            console.log('[RESPONSE] ⚠️ Unexpected status:', response.status);
        }
        return response;
    })
    .then(response => {
        console.log('[FINAL] Response status:', response.status);
        console.log('[FINAL] Parsing JSON response...');
        return response.json();
    })
    .then(data => {
        console.log('[SUCCESS] Response data received:', data);
        document.getElementById('loadingSpinner').classList.remove('show');

        if (data.error) {
            console.log('[ERROR] Server returned error:', data.error);
            showError(data.error);
        } else {
            console.log('[SUCCESS] Address check complete');
            console.log('[SUCCESS] In ZSP:', data.in_zsp);
            console.log('[SUCCESS] Zones:', data.zones);
            showResult(data);
            updateMap(data.map_html);
            addToHistory(address, data.in_zsp);
        }
    })
    .catch(error => {
        console.log('[FATAL] Request failed with error:', error);
        console.error('Error details:', error);
        document.getElementById('loadingSpinner').classList.remove('show');
        showError('Une erreur est survenue lors de la vérification.');
    });
}

function showResult(data) {
    const resultCard = document.getElementById('resultCard');
    const resultContent = document.getElementById('resultContent');

    let html = '';
    if (data.in_zsp) {
        const zone = data.zones[0];
        html = `
            <div class="alert alert-error">
                <div class="alert-title">
                    <i class="fas fa-exclamation-triangle alert-icon"></i>
                    <span>Zone de Sécurité Prioritaire</span>
                </div>
                <div class="alert-content">
                    Cette adresse est située dans une ZSP
                </div>
            </div>
            <div class="result-item">
                <span class="result-label">Zone</span>
                <span class="result-value">${zone.name}</span>
            </div>
            <div class="result-item">
                <span class="result-label">Département</span>
                <span class="result-value">${zone.department}</span>
            </div>
            <div class="result-item">
                <span class="result-label">Compétence</span>
                <span class="result-value">
                    <span class="zone-badge zone-${zone.competence.toLowerCase()}">
                        ${zone.competence}
                    </span>
                </span>
            </div>
            <div class="result-item">
                <span class="result-label">Coordonnées</span>
                <span class="result-value">${data.coordinates.lat.toFixed(6)}, ${data.coordinates.lon.toFixed(6)}</span>
            </div>
        `;
    } else {
        html = `
            <div class="alert alert-success">
                <div class="alert-title">
                    <i class="fas fa-check-circle alert-icon"></i>
                    <span>Hors Zone de Sécurité Prioritaire</span>
                </div>
                <div class="alert-content">
                    Cette adresse n'est pas située dans une ZSP
                </div>
            </div>
            <div class="result-item">
                <span class="result-label">Adresse vérifiée</span>
                <span class="result-value">${data.address}</span>
            </div>
            <div class="result-item">
                <span class="result-label">Coordonnées</span>
                <span class="result-value">${data.coordinates.lat.toFixed(6)}, ${data.coordinates.lon.toFixed(6)}</span>
            </div>
        `;
    }

    resultContent.innerHTML = html;
    resultCard.classList.add('show');
}

function showError(message) {
    const errorDiv = document.getElementById('errorMessage');
    const errorContent = document.getElementById('errorContent');
    errorContent.textContent = message;
    errorDiv.style.display = 'block';
}

function updateMap(mapHtml) {
    document.getElementById('map').innerHTML = mapHtml;
    fixMapSize();
}

function fixMapSize() {
    // Fix Folium map sizing issues
    setTimeout(function() {
        const mapDiv = document.querySelector('#map > div');
        if (mapDiv) {
            mapDiv.style.position = 'absolute';
            mapDiv.style.width = '100%';
            mapDiv.style.height = '100%';
            mapDiv.style.padding = '0';

            // Remove any padding-bottom from nested divs
            const nestedDivs = mapDiv.querySelectorAll('div[style*="padding-bottom"]');
            nestedDivs.forEach(div => {
                div.style.paddingBottom = '0';
                div.style.height = '100%';
            });

            const iframe = mapDiv.querySelector('iframe');
            if (iframe) {
                iframe.style.position = 'absolute';
                iframe.style.width = '100%';
                iframe.style.height = '100%';
            }
        }
    }, 100);
}

// Initial page load diagnostics
window.addEventListener('DOMContentLoaded', function() {
    console.log('========================================');
    console.log('[INIT] Page loaded - Checking XSRF token status');
    console.log('[INIT] Current URL:', window.location.href);
    console.log('[INIT] Current origin:', window.location.origin);
    console.log('[INIT] Current pathname:', window.location.pathname);
    console.log('[INIT] Checking for JupyterHub environment...');

    // Check if we're running in JupyterHub by looking at URL patterns
    if (window.location.pathname.includes('/user/') ||
        window.location.pathname.includes('/hub/') ||
        window.location.pathname.includes('/proxy/')) {
        console.log('[INIT] ✅ Detected JupyterHub environment');
    } else {
        console.log('[INIT] ⚠️ Not detected as JupyterHub environment');
    }

    // Check cookies on page load
    console.log('[INIT] Checking cookies on page load...');
    console.log('[INIT] All cookies:', document.cookie || 'No cookies found');

    // Try to extract XSRF token on load
    const initialToken = getXSRFToken();
    if (initialToken) {
        console.log('[INIT] ✅ XSRF token found on page load');
        console.log('[INIT] Token preview:', initialToken.substring(0, 20) + '...');
    } else {
        console.log('[INIT] ⚠️ No XSRF token found on page load');
        console.log('[INIT] This is expected if not running behind JupyterHub');
    }
    console.log('========================================');
});

window.addEventListener('load', fixMapSize);
window.addEventListener('resize', fixMapSize);

function addToHistory(address, inZsp) {
    searchHistory = searchHistory.filter(h => h.address !== address);
    searchHistory.unshift({address: address, inZsp: inZsp});

    if (searchHistory.length > maxHistory) {
        searchHistory = searchHistory.slice(0, maxHistory);
    }

    const historyDiv = document.getElementById('searchHistory');
    if (searchHistory.length === 0) {
        historyDiv.innerHTML = `
            <div style="color: var(--rf-grey-dark); font-size: 14px; text-align: center; padding: 16px;">
                Aucune recherche effectuée
            </div>
        `;
    } else {
        historyDiv.innerHTML = searchHistory.map(item => `
            <div class="history-item" onclick="searchAddress('${item.address}')" style="margin: 0;">
                <i class="fas fa-map-marker-alt history-icon" style="color: ${item.inZsp ? 'var(--rf-error)' : 'var(--rf-success)'};"></i>
                <span>${item.address}</span>
            </div>
        `).join('');
    }
}

function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    sidebar.classList.toggle('active');
}

// Close sidebar when clicking outside on mobile
document.addEventListener('click', function(event) {
    const sidebar = document.getElementById('sidebar');
    const toggle = document.getElementById('mobileToggle');

    if (window.innerWidth <= 768 &&
        sidebar.classList.contains('active') &&
        !sidebar.contains(event.target) &&
        !toggle.contains(event.target)) {
        sidebar.classList.remove('active');
    }
});