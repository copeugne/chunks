let searchHistory = [];
const maxHistory = 5;

document.getElementById('searchForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const address = document.getElementById('addressInput').value.trim();
    if (address) {
        searchAddress(address);
    }
});

// Client-side geocoding using Nominatim API
async function geocodeAddress(address) {
    // Add France to address if not already present
    let searchAddress = address;
    if (!address.toLowerCase().includes('france')) {
        searchAddress = address + ', France';
    }

    const params = new URLSearchParams({
        q: searchAddress,
        format: 'json',
        limit: '1',
        countrycodes: 'fr'
    });

    try {
        const response = await fetch(`https://nominatim.openstreetmap.org/search?${params}`, {
            headers: {
                'Accept': 'application/json'
            }
        });

        if (!response.ok) {
            throw new Error('Geocoding API request failed');
        }

        const data = await response.json();

        if (data && data.length > 0) {
            const result = data[0];
            return {
                lat: parseFloat(result.lat),
                lon: parseFloat(result.lon),
                display_name: result.display_name
            };
        } else {
            return null;
        }
    } catch (error) {
        console.error('Geocoding error:', error);
        return null;
    }
}

// Helper function to get XSRF token from cookies
function getXSRFToken() {
    const cookies = document.cookie.split(';');
    for (let cookie of cookies) {
        const [name, value] = cookie.trim().split('=');
        if (name === '_xsrf') {
            return decodeURIComponent(value);
        }
    }
    return null;
}

async function searchAddress(address) {
    document.getElementById('addressInput').value = address;

    document.getElementById('loadingSpinner').classList.add('show');
    document.getElementById('resultCard').classList.remove('show');
    document.getElementById('errorMessage').style.display = 'none';

    // First try to geocode the address client-side
    console.log('Geocoding address client-side:', address);
    const geocodeResult = await geocodeAddress(address);

    // Prepare request data as JSON
    const requestData = {
        address: address
    };

    if (geocodeResult) {
        console.log('Geocoding successful:', geocodeResult);
        requestData.lat = geocodeResult.lat;
        requestData.lon = geocodeResult.lon;
    } else {
        console.log('Client-side geocoding failed, will try server-side');
    }

    // Try JSON request first (often bypasses CSRF)
    fetch('/check_address', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
        },
        credentials: 'same-origin',
        body: JSON.stringify(requestData)
    })
    .then(async response => {
        if (response.status === 403) {
            // CSRF error, try with form-encoded and XSRF token
            console.log('JSON request failed with 403, trying form-encoded with XSRF token');

            let body = 'address=' + encodeURIComponent(address);
            if (geocodeResult) {
                body += '&lat=' + encodeURIComponent(geocodeResult.lat);
                body += '&lon=' + encodeURIComponent(geocodeResult.lon);
            }

            // Add XSRF token if available
            const xsrfToken = getXSRFToken();
            if (xsrfToken) {
                body += '&_xsrf=' + encodeURIComponent(xsrfToken);
            }

            return fetch('/check_address', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                credentials: 'same-origin',
                body: body
            });
        }
        return response;
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById('loadingSpinner').classList.remove('show');

        if (data.error) {
            showError(data.error);
        } else {
            showResult(data);
            updateMap(data.map_html);
            addToHistory(address, data.in_zsp);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        document.getElementById('loadingSpinner').classList.remove('show');
        showError('Une erreur est survenue lors de la vérification.');
    });
}

function showResult(data) {
    const resultCard = document.getElementById('resultCard');
    const resultContent = document.getElementById('resultContent');

    let html = '';
    if (data.in_zsp) {
        const zone = data.zones[0];
        html = `
            <div class="alert alert-error">
                <div class="alert-title">
                    <i class="fas fa-exclamation-triangle alert-icon"></i>
                    <span>Zone de Sécurité Prioritaire</span>
                </div>
                <div class="alert-content">
                    Cette adresse est située dans une ZSP
                </div>
            </div>
            <div class="result-item">
                <span class="result-label">Zone</span>
                <span class="result-value">${zone.name}</span>
            </div>
            <div class="result-item">
                <span class="result-label">Département</span>
                <span class="result-value">${zone.department}</span>
            </div>
            <div class="result-item">
                <span class="result-label">Compétence</span>
                <span class="result-value">
                    <span class="zone-badge zone-${zone.competence.toLowerCase()}">
                        ${zone.competence}
                    </span>
                </span>
            </div>
            <div class="result-item">
                <span class="result-label">Coordonnées</span>
                <span class="result-value">${data.coordinates.lat.toFixed(6)}, ${data.coordinates.lon.toFixed(6)}</span>
            </div>
        `;
    } else {
        html = `
            <div class="alert alert-success">
                <div class="alert-title">
                    <i class="fas fa-check-circle alert-icon"></i>
                    <span>Hors Zone de Sécurité Prioritaire</span>
                </div>
                <div class="alert-content">
                    Cette adresse n'est pas située dans une ZSP
                </div>
            </div>
            <div class="result-item">
                <span class="result-label">Adresse vérifiée</span>
                <span class="result-value">${data.address}</span>
            </div>
            <div class="result-item">
                <span class="result-label">Coordonnées</span>
                <span class="result-value">${data.coordinates.lat.toFixed(6)}, ${data.coordinates.lon.toFixed(6)}</span>
            </div>
        `;
    }

    resultContent.innerHTML = html;
    resultCard.classList.add('show');
}

function showError(message) {
    const errorDiv = document.getElementById('errorMessage');
    const errorContent = document.getElementById('errorContent');
    errorContent.textContent = message;
    errorDiv.style.display = 'block';
}

function updateMap(mapHtml) {
    document.getElementById('map').innerHTML = mapHtml;
    fixMapSize();
}

function fixMapSize() {
    // Fix Folium map sizing issues
    setTimeout(function() {
        const mapDiv = document.querySelector('#map > div');
        if (mapDiv) {
            mapDiv.style.position = 'absolute';
            mapDiv.style.width = '100%';
            mapDiv.style.height = '100%';
            mapDiv.style.padding = '0';

            // Remove any padding-bottom from nested divs
            const nestedDivs = mapDiv.querySelectorAll('div[style*="padding-bottom"]');
            nestedDivs.forEach(div => {
                div.style.paddingBottom = '0';
                div.style.height = '100%';
            });

            const iframe = mapDiv.querySelector('iframe');
            if (iframe) {
                iframe.style.position = 'absolute';
                iframe.style.width = '100%';
                iframe.style.height = '100%';
            }
        }
    }, 100);
}

window.addEventListener('load', fixMapSize);
window.addEventListener('resize', fixMapSize);

function addToHistory(address, inZsp) {
    searchHistory = searchHistory.filter(h => h.address !== address);
    searchHistory.unshift({address: address, inZsp: inZsp});

    if (searchHistory.length > maxHistory) {
        searchHistory = searchHistory.slice(0, maxHistory);
    }

    const historyDiv = document.getElementById('searchHistory');
    if (searchHistory.length === 0) {
        historyDiv.innerHTML = `
            <div style="color: var(--rf-grey-dark); font-size: 14px; text-align: center; padding: 16px;">
                Aucune recherche effectuée
            </div>
        `;
    } else {
        historyDiv.innerHTML = searchHistory.map(item => `
            <div class="history-item" onclick="searchAddress('${item.address}')" style="margin: 0;">
                <i class="fas fa-map-marker-alt history-icon" style="color: ${item.inZsp ? 'var(--rf-error)' : 'var(--rf-success)'};"></i>
                <span>${item.address}</span>
            </div>
        `).join('');
    }
}

function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    sidebar.classList.toggle('active');
}

// Close sidebar when clicking outside on mobile
document.addEventListener('click', function(event) {
    const sidebar = document.getElementById('sidebar');
    const toggle = document.getElementById('mobileToggle');

    if (window.innerWidth <= 768 &&
        sidebar.classList.contains('active') &&
        !sidebar.contains(event.target) &&
        !toggle.contains(event.target)) {
        sidebar.classList.remove('active');
    }
});