URL : https://www.hatvp.fr/le-repertoire/liste-des-entites-enregistrees/?filter=actifs

XPATH entity anchor tag : //[@id="afficherSeulementQuiOntPublie"]/div[1]/div[1]/a
XPATH entity name : //[@id="afficherSeulementQuiOntPublie"]/div[1]/div[1]/a/div[1]/div[1]/div[1]/span
XPATH entity type : //[@id="afficherSeulementQuiOntPublie"]/div[1]/div[1]/a/div[1]/div[1]/div[2]/div[1]/span[2]
XPATH registration date : //[@id="afficherSeulementQuiOntPublie"]/div[1]/div[1]/a/div[1]/div[2]/div[2]/div[1]/span[2]
