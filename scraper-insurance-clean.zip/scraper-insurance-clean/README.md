## Installation

# Clone the repository and navigate to it
```bash
git clone insurance-scraper && cd insurance-scraper
```

# Install UV
```bash
pip install uv
```

# Install with UV (highly recommended)
```bash
uv sync
```

## Quick Start

### Basic Usage

```bash
# Scrape with default settings (uses URL from XPATHs.md files)
scrape-insurance

# Custom URL with JSON output
scrape-insurance --url "https://www.fitchratings.com/search/?filter.sector=Insurance" --format json

# Visible browser mode with verbose logging
scrape-insurance --no-headless --verbose
```

### Advanced Usage

```bash
# Custom output directory and filename
scrape-insurance --format csv --filename my_results.csv --output-dir /path/to/output

# Custom rate limiting and timeout
scrape-insurance --rate-limit 3.0 --timeout 15
```

## Configuration

The scraper uses XPath selectors defined in `XPATHs.md` files:
- **Entity Name**: `//*[@id="main-content"]/section[1]/div/div[2]/div[2]/div[1]/h3/a`
- **Sector and Country**: `//*[@id="main-content"]/section[1]/div/div[2]/div[2]/div[3]/p`

## Output Formats

### CSV
Structured data with columns: entity_name, sector, country, url

### JSON
Structured data with metadata:
```json
{
  "metadata": {
    "export_timestamp": "2025-09-25T10:30:00",
    "total_entities": 150,
    "source": "Fitch Ratings Insurance Entities"
  },
  "entities": [...]
}
```

## Requirements

- Python 3.9+
- Chrome browser (for WebDriver)
- Dependencies managed via `pyproject.toml`
