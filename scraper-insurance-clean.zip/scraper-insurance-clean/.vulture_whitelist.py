"""Vulture whitelist for false positives."""

# Selenium ChromeOptions - used by external library
binary_location

# Test mocking - used by unittest.mock framework
__enter__
__exit__
side_effect
