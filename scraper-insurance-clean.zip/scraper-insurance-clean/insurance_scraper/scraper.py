"""Main scraper module for extracting insurance entity data from Fitch Ratings."""

from __future__ import annotations

import logging
import re
import shutil
import time
from dataclasses import asdict, dataclass
from typing import Optional

from selenium import webdriver
from selenium.common.exceptions import (
    NoSuchElementException,
    TimeoutException,
    WebDriverException,
)
from selenium.webdriver.chrome.options import Options as ChromeOptions
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.common.by import By
from selenium.webdriver.firefox.options import Options as FirefoxOptions
from selenium.webdriver.firefox.service import Service as FirefoxService
from selenium.webdriver.remote.webdriver import WebDriver
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from webdriver_manager.chrome import ChromeDriverManager
from webdriver_manager.firefox import GeckoDriverManager

from .utils import (
    RateLimiter,
    log_scraping_stats,
    parse_sector_country,
    retry_on_failure,
    safe_get_attribute,
    safe_get_text,
    validate_url,
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler("scraper.log"),
        logging.StreamHandler(),
    ],
)
logger = logging.getLogger(__name__)


@dataclass
class InsuranceEntity:
    """Data class for storing insurance entity information from Fitch Ratings."""

    entity_name: str
    sector: str
    country: str
    url: Optional[str] = None


@dataclass
class HATVPEntity:
    """Data class for storing HATVP entity information."""

    entity_name: str
    entity_type: str
    registration_date: str
    url: Optional[str] = None


@dataclass
class FranceAssureursEntity:
    """Data class for storing insurance entity information from France Assureurs."""

    insurance_name: str
    group_name: str
    building_complex: str
    street: str
    postal_code_city: str
    url: str
    phone_number: str


@dataclass
class ABEEntity:
    """Data class for storing blacklist entity information from ABE Info Service."""

    url_mail_name: str
    denomination: str
    category: str
    date_added: str


class FitchRatingsScraper:
    """Scraper for extracting insurance entity data from Fitch Ratings."""

    def __init__(
        self,
        headless: bool = True,
        timeout: int = 10,
        rate_limit: float = 2.0,
        max_pages: int = 100,
    ) -> None:
        """Initialize the scraper with WebDriver configuration.

        Args:
            headless: Whether to run browser in headless mode
            timeout: Timeout in seconds for WebDriver waits
            rate_limit: Minimum interval between requests in seconds
            max_pages: Maximum number of pages to scrape
        """
        self.headless = headless
        self.timeout = timeout
        self.max_pages = max_pages
        self.driver: Optional[WebDriver] = None
        self.wait: Optional[WebDriverWait[WebDriver]] = None
        self.rate_limiter = RateLimiter(rate_limit)

        # XPath selectors from XPATHs.md (with N placeholder for iteration)
        self.entity_name_xpath_template = (
            '//*[@id="main-content"]/section[1]/div/div[2]/div[N]/div[1]/h3/a'
        )
        self.sector_country_xpath_template = (
            '//*[@id="main-content"]/section[1]/div/div[2]/div[N]/div[3]/p'
        )

        # End-of-pages indicator XPath (when this is missing, we've reached the end)
        self.end_of_pages_xpath = '//*[@id="main-content"]/section[1]/div/div[1]/p'

    @retry_on_failure(max_attempts=3, delay=2.0)
    def _setup_driver(self) -> None:
        """Set up WebDriver with fallback browser options."""
        drivers_to_try = [
            ("Chrome", self._setup_chrome),
            ("Firefox", self._setup_firefox),
        ]

        last_error = None
        for browser_name, setup_func in drivers_to_try:
            try:
                logger.info(f"Attempting to initialize {browser_name} WebDriver...")
                setup_func()
                logger.info(f"{browser_name} WebDriver initialized successfully")
                return
            except Exception as e:
                logger.warning(f"Failed to initialize {browser_name}: {e}")
                last_error = e
                continue

        # If all browsers failed, raise the last error
        logger.error("All WebDriver initialization attempts failed")
        raise WebDriverException(
            f"Could not initialize any WebDriver. Last error: {last_error}"
        )

    def _setup_chrome(self) -> None:
        """Set up Chrome WebDriver."""
        chrome_options = ChromeOptions()

        if self.headless:
            chrome_options.add_argument("--headless")

        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--disable-gpu")
        chrome_options.add_argument("--window-size=1920,1080")
        chrome_options.add_argument("--disable-blink-features=AutomationControlled")
        chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
        chrome_options.add_experimental_option("useAutomationExtension", False)
        chrome_options.add_argument(
            "--user-agent=Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36"
        )

        # Set binary location for Chromium if using system Chromium
        chromium_path = shutil.which("chromium") or shutil.which("chromium-browser")
        if chromium_path:
            chrome_options.binary_location = chromium_path

        # Try system chromedriver first (now that it's installed)
        try:
            service = ChromeService()  # Uses system chromedriver
            self.driver = webdriver.Chrome(service=service, options=chrome_options)
            logger.info("Using system ChromeDriver")
        except Exception as e1:
            logger.warning(f"Failed with system ChromeDriver: {e1}")
            try:
                # Fallback to webdriver-manager
                service = ChromeService(
                    ChromeDriverManager(driver_version="LATEST").install()
                )
                self.driver = webdriver.Chrome(service=service, options=chrome_options)
                logger.info("Using webdriver-manager ChromeDriver")
            except Exception as e2:
                logger.warning(f"Failed with webdriver-manager: {e2}")
                raise e1 from e2

        self.wait = WebDriverWait(self.driver, self.timeout)

    def _setup_firefox(self) -> None:
        """Set up Firefox WebDriver as fallback."""
        firefox_options = FirefoxOptions()

        if self.headless:
            firefox_options.add_argument("--headless")

        firefox_options.add_argument("--no-sandbox")
        firefox_options.add_argument("--disable-dev-shm-usage")

        try:
            service = FirefoxService()
            self.driver = webdriver.Firefox(service=service, options=firefox_options)
        except Exception:
            # Fallback to webdriver-manager
            service = FirefoxService(GeckoDriverManager().install())
            self.driver = webdriver.Firefox(service=service, options=firefox_options)

        self.wait = WebDriverWait(self.driver, self.timeout)

    def _teardown_driver(self) -> None:
        """Clean up WebDriver resources."""
        if self.driver:
            try:
                self.driver.quit()
                logger.info("WebDriver closed successfully")
            except Exception as e:
                logger.warning(f"Error closing WebDriver: {e}")
            finally:
                self.driver = None
                self.wait = None

    def _has_more_pages(self) -> bool:
        """Check if there are more pages to scrape.

        Returns:
            True if more pages exist, False if we've reached the end
        """
        assert self.driver is not None, "WebDriver not initialized"
        try:
            # Check for the presence of the end-of-pages indicator
            self.driver.find_element(By.XPATH, self.end_of_pages_xpath)
            return True
        except NoSuchElementException:
            logger.info("End-of-pages indicator not found - reached last page")
            return False

    def _extract_page_entities(self) -> list[InsuranceEntity]:
        """Extract entity data from the current single page.

        Returns:
            List of InsuranceEntity objects with scraped data from current page
        """
        assert self.driver is not None, "WebDriver not initialized"
        assert self.wait is not None, "WebDriverWait not initialized"

        entities: list[InsuranceEntity] = []

        try:
            # Wait for the main content to load
            logger.debug("Waiting for main-content element...")
            self.wait.until(EC.presence_of_element_located((By.ID, "main-content")))

            # Check if we've reached the end of pages
            if not self._has_more_pages():
                logger.info("No more pages to scrape")
                return entities

            # Find all result containers (div[N] elements)
            result_containers_xpath = (
                '//*[@id="main-content"]/section[1]/div/div[2]/div[position()>1]'
            )
            result_containers = self.driver.find_elements(
                By.XPATH, result_containers_xpath
            )

            if not result_containers:
                logger.warning("No result containers found on the current page")
                return entities

            logger.debug(
                f"Found {len(result_containers)} result containers on current page"
            )

            # Extract data for each result container
            for i, _container in enumerate(
                result_containers, start=2
            ):  # Start at 2 since div[1] is likely header
                try:
                    # Generate XPaths for this specific container index
                    entity_name_xpath = self.entity_name_xpath_template.replace(
                        "[N]", f"[{i}]"
                    )
                    sector_country_xpath = self.sector_country_xpath_template.replace(
                        "[N]", f"[{i}]"
                    )

                    logger.debug(f"Processing container {i}: {entity_name_xpath}")

                    # Extract entity name and URL
                    try:
                        name_element = self.driver.find_element(
                            By.XPATH, entity_name_xpath
                        )
                        entity_name = safe_get_text(name_element, "Unknown Entity")
                        entity_url = safe_get_attribute(name_element, "href")
                    except NoSuchElementException:
                        logger.debug(f"No entity name found in container {i}")
                        continue

                    # Extract sector and country
                    try:
                        sector_element = self.driver.find_element(
                            By.XPATH, sector_country_xpath
                        )
                        sector_country = safe_get_text(sector_element, "Unknown")
                    except NoSuchElementException:
                        logger.warning(
                            f"Sector/country information not found for container {i}"
                        )
                        sector_country = "Unknown"

                    # Skip entities with no meaningful data
                    if entity_name == "Unknown Entity":
                        logger.debug(
                            f"Skipping container {i} with no meaningful entity name"
                        )
                        continue

                    # Parse sector and country from combined text
                    sector, country = parse_sector_country(sector_country)

                    # Create entity object
                    entity = InsuranceEntity(
                        entity_name=entity_name,
                        sector=sector,
                        country=country,
                        url=entity_url,
                    )

                    entities.append(entity)
                    logger.debug(f"Extracted entity {len(entities)}: {entity_name}")

                except Exception as e:
                    logger.error(f"Error extracting data for container {i}: {e}")
                    continue

            logger.debug(
                f"Successfully extracted {len(entities)} entities from current page"
            )
            return entities

        except TimeoutException:
            logger.error("Timeout waiting for page elements to load")
            raise
        except Exception as e:
            logger.error(f"Error extracting entity data from page: {e}")
            raise

    def _extract_entity_data(
        self, base_url: str, max_pages: int = 100
    ) -> list[InsuranceEntity]:
        """Extract entity data from all pages.

        Args:
            base_url: Base URL template with N placeholder for page numbers
            max_pages: Maximum number of pages to scrape

        Returns:
            List of InsuranceEntity objects with scraped data from all pages
        """
        assert self.driver is not None, "WebDriver not initialized"

        all_entities: list[InsuranceEntity] = []
        page_number = 1

        try:
            while page_number <= max_pages:
                # Generate URL for current page
                current_url = base_url.replace("page=N", f"page={page_number}")

                logger.info(f"Scraping page {page_number}: {current_url[:100]}...")

                # Apply rate limiting
                self.rate_limiter.wait_if_needed()

                # Navigate to the page
                self.driver.get(current_url)

                # Wait for page to load
                time.sleep(3)

                # Extract entities from current page
                page_entities = self._extract_page_entities()

                if not page_entities:
                    if page_number == 1:
                        # No entities on first page - might be an issue
                        logger.warning("No entities found on first page")
                        break
                    # No entities on subsequent page - we've reached the end
                    logger.info(
                        f"No entities found on page {page_number} - reached end of results"
                    )
                    break

                all_entities.extend(page_entities)
                logger.info(
                    f"Page {page_number}: Found {len(page_entities)} entities (Total: {len(all_entities)})"
                )

                page_number += 1

            logger.info(
                f"Pagination complete - scraped {len(all_entities)} entities from {page_number - 1} pages"
            )
            return all_entities

        except Exception as e:
            logger.error(f"Error during pagination: {e}")
            raise

    @retry_on_failure(max_attempts=3, delay=5.0)
    def scrape_url(self, url: str) -> list[InsuranceEntity]:
        """Scrape insurance entities from the given URL.

        Args:
            url: Target URL to scrape

        Returns:
            List of InsuranceEntity objects

        Raises:
            WebDriverException: If there are issues with browser automation
            TimeoutException: If page loading times out
            ValueError: If URL is invalid
        """
        if not validate_url(url):
            raise ValueError(f"Invalid URL provided: {url}")

        if not self.driver:
            self._setup_driver()

        start_time = time.time()
        errors_count = 0

        try:
            logger.info("Starting pagination-enabled scraping...")

            # Extract entity data from all pages
            entities = self._extract_entity_data(url, self.max_pages)

            # Log scraping statistics
            log_scraping_stats(len(entities), start_time, url, errors_count)

            return entities

        except Exception as e:
            errors_count += 1
            logger.error(f"Error scraping URL {url}: {e}")
            raise

    def __enter__(self) -> FitchRatingsScraper:
        """Context manager entry."""
        self._setup_driver()
        return self

    def __exit__(self, _exc_type: object, _exc_val: object, _exc_tb: object) -> None:
        """Context manager exit."""
        self._teardown_driver()


class HATVPScraper:
    """Scraper for extracting entity data from HATVP (Haute Autorité pour la transparence de la vie publique)."""

    def __init__(
        self, headless: bool = True, timeout: int = 10, rate_limit: float = 2.0
    ) -> None:
        """Initialize the scraper with WebDriver configuration.

        Args:
            headless: Whether to run browser in headless mode
            timeout: Timeout in seconds for WebDriver waits
            rate_limit: Minimum interval between requests in seconds
        """
        self.headless = headless
        self.timeout = timeout
        self.driver: Optional[WebDriver] = None
        self.wait: Optional[WebDriverWait[WebDriver]] = None
        self.rate_limiter = RateLimiter(rate_limit)

    def _setup_driver(self) -> None:
        """Set up Chrome WebDriver with appropriate options."""
        try:
            logger.info("Attempting to initialize Chrome WebDriver...")

            chrome_options = ChromeOptions()
            if self.headless:
                chrome_options.add_argument("--headless")

            chrome_options.add_argument("--no-sandbox")
            chrome_options.add_argument("--disable-dev-shm-usage")
            chrome_options.add_argument("--disable-gpu")
            chrome_options.add_argument("--window-size=1920,1080")

            try:
                # Try system ChromeDriver first
                service = ChromeService("/usr/bin/chromedriver")
                self.driver = webdriver.Chrome(service=service, options=chrome_options)
                logger.info("Using system ChromeDriver")
            except Exception:
                # Fallback to webdriver-manager
                service = ChromeService(ChromeDriverManager().install())
                self.driver = webdriver.Chrome(service=service, options=chrome_options)
                logger.info("Using webdriver-manager ChromeDriver")

            self.wait = WebDriverWait(self.driver, self.timeout)
            logger.info("Chrome WebDriver initialized successfully")

        except Exception as e:
            logger.error(f"Failed to initialize Chrome WebDriver: {e}")
            if self.driver:
                self.driver.quit()
            raise WebDriverException(
                f"Chrome WebDriver initialization failed: {e}"
            ) from e

    def _teardown_driver(self) -> None:
        """Clean up WebDriver resources."""
        if self.driver:
            try:
                self.driver.quit()
                logger.info("WebDriver closed successfully")
            except Exception as e:
                logger.warning(f"Error closing WebDriver: {e}")

    def _extract_entity_from_anchor(
        self, anchor_element: WebElement, index: int
    ) -> Optional[HATVPEntity]:
        """Extract a single entity from an anchor element.

        Args:
            anchor_element: The anchor WebElement to extract from
            index: Index of the anchor for logging purposes

        Returns:
            HATVPEntity if successfully extracted, None otherwise
        """
        spans = anchor_element.find_elements(By.TAG_NAME, "span")

        # Debug: Print first 10 anchors' structure
        if index <= 10:
            logger.debug(f"=== DEBUG Anchor {index} ===")
            logger.debug(f"Number of spans: {len(spans)}")
            logger.debug(f"Anchor href: {safe_get_attribute(anchor_element, 'href')}")
            logger.debug(f"Anchor text: {safe_get_text(anchor_element, 'N/A')}")
            for j, span in enumerate(spans):
                span_text = safe_get_text(span, "")
                logger.debug(f"  Span[{j}]: '{span_text}'")
            logger.debug("===================")

        # Current structure (as of 2025):
        # Span[0]: Entity name
        # Span[1]: "Date d'inscription" (label - skip)
        # Span[2]: Registration date
        if len(spans) < 3:
            logger.debug(
                f"Entity {index}: Not enough spans found ({len(spans)}), skipping"
            )
            return None

        # Extract data from the spans
        entity_name = safe_get_text(spans[0], "Unknown")
        registration_date = safe_get_text(spans[2], "Unknown")
        entity_url = safe_get_attribute(anchor_element, "href")

        # Entity type is no longer in the span structure - try to extract from other divs
        entity_type = "Unknown"
        try:
            # Try to find type in nested divs within the anchor
            type_divs = anchor_element.find_elements(By.TAG_NAME, "div")
            for div in type_divs:
                div_text = safe_get_text(div, "")
                # Look for type indicators
                if any(
                    keyword in div_text.lower()
                    for keyword in [
                        "association",
                        "entreprise",
                        "organisation",
                        "syndicat",
                    ]
                ):
                    entity_type = div_text
                    break
        except Exception as e:
            logger.debug(f"Could not extract entity type for entity {index}: {e}")

        # Skip entities with no meaningful data
        if entity_name == "Unknown" or not entity_name.strip():
            logger.debug(f"Skipping entity {index} with no meaningful name")
            return None

        # Create and return entity object
        return HATVPEntity(
            entity_name=entity_name,
            entity_type=entity_type,
            registration_date=registration_date,
            url=entity_url,
        )

    def _extract_entities_from_page(self, url: str) -> list[HATVPEntity]:
        """Extract all entities from the HATVP page.

        Args:
            url: URL to scrape

        Returns:
            List of HATVPEntity objects
        """
        assert self.driver is not None, "WebDriver not initialized"
        assert self.wait is not None, "WebDriverWait not initialized"

        logger.info(f"Navigating to: {url}")
        self.driver.get(url)

        # Wait for the content to load
        try:
            self.wait.until(
                EC.presence_of_element_located((By.ID, "afficherSeulementQuiOntPublie"))
            )
            logger.debug("Main container loaded")
        except TimeoutException:
            logger.warning("Timeout waiting for content to load")
            return []

        # Wait a bit more for dynamic content to load
        time.sleep(3)
        logger.debug("Waited for dynamic content to load")

        # Wait specifically for anchor elements to be present
        try:
            self.wait.until(
                EC.presence_of_element_located(
                    (By.XPATH, '//*[@id="afficherSeulementQuiOntPublie"]//a')
                )
            )
            logger.debug("Anchor elements are now present")
        except TimeoutException:
            logger.warning("Timeout waiting for anchor elements to load")
            return []

        # Find all anchor elements containing entities
        try:
            anchor_elements = self.driver.find_elements(
                By.XPATH, '//*[@id="afficherSeulementQuiOntPublie"]//a'
            )
            logger.info(f"Found {len(anchor_elements)} potential entities")
        except NoSuchElementException:
            logger.warning("No entity anchors found")
            return []

        entities = []

        for i, anchor_element in enumerate(anchor_elements, 1):
            try:
                entity = self._extract_entity_from_anchor(anchor_element, i)
                if entity:
                    entities.append(entity)
                    logger.debug(
                        f"Extracted entity {len(entities)}: {entity.entity_name}"
                    )
            except Exception as e:
                logger.warning(f"Error processing entity {i}: {e}")
                continue

        logger.info(f"Successfully extracted {len(entities)} entities")
        return entities

    def scrape_url(self, url: str) -> list[HATVPEntity]:
        """Scrape HATVP entities from the given URL.

        Args:
            url: Target URL to scrape

        Returns:
            List of HATVPEntity objects

        Raises:
            WebDriverException: If there are issues with browser automation
            TimeoutException: If page loading times out
            ValueError: If URL is invalid
        """
        if not validate_url(url):
            raise ValueError(f"Invalid URL provided: {url}")

        if not self.driver:
            self._setup_driver()

        start_time = time.time()
        errors_count = 0

        try:
            logger.info("Starting HATVP scraping...")

            # Apply rate limiting
            self.rate_limiter.wait_if_needed()

            # Extract entity data from the page
            entities = self._extract_entities_from_page(url)

            # Log scraping statistics
            log_scraping_stats(len(entities), start_time, url, errors_count)

            return entities

        except Exception as e:
            errors_count += 1
            logger.error(f"Error scraping URL {url}: {e}")
            raise

    def __enter__(self) -> HATVPScraper:
        """Context manager entry."""
        self._setup_driver()
        return self

    def __exit__(self, _exc_type: object, _exc_val: object, _exc_tb: object) -> None:
        """Context manager exit."""
        self._teardown_driver()


class FranceAssureursScraper:
    """Scraper for extracting insurance entity data from France Assureurs."""

    def __init__(
        self, headless: bool = True, timeout: int = 10, rate_limit: float = 2.0
    ) -> None:
        """Initialize the scraper with WebDriver configuration.

        Args:
            headless: Whether to run browser in headless mode
            timeout: Timeout in seconds for WebDriver waits
            rate_limit: Minimum interval between requests in seconds
        """
        self.headless = headless
        self.timeout = timeout
        self.driver: Optional[WebDriver] = None
        self.wait: Optional[WebDriverWait[WebDriver]] = None
        self.rate_limiter = RateLimiter(rate_limit)

    def _setup_driver(self) -> None:
        """Set up Chrome WebDriver with appropriate options."""
        try:
            logger.info("Attempting to initialize Chrome WebDriver...")

            chrome_options = ChromeOptions()
            if self.headless:
                chrome_options.add_argument("--headless")

            chrome_options.add_argument("--no-sandbox")
            chrome_options.add_argument("--disable-dev-shm-usage")
            chrome_options.add_argument("--disable-gpu")
            chrome_options.add_argument("--window-size=1920,1080")

            try:
                # Try system ChromeDriver first
                service = ChromeService("/usr/bin/chromedriver")
                self.driver = webdriver.Chrome(service=service, options=chrome_options)
                logger.info("Using system ChromeDriver")
            except Exception:
                # Fallback to webdriver-manager
                service = ChromeService(ChromeDriverManager().install())
                self.driver = webdriver.Chrome(service=service, options=chrome_options)
                logger.info("Using webdriver-manager ChromeDriver")

            self.wait = WebDriverWait(self.driver, self.timeout)
            logger.info("Chrome WebDriver initialized successfully")

        except Exception as e:
            logger.error(f"Failed to initialize Chrome WebDriver: {e}")
            raise WebDriverException(f"WebDriver setup failed: {e}") from e

    def _teardown_driver(self) -> None:
        """Clean up WebDriver resources."""
        if self.driver:
            try:
                self.driver.quit()
                logger.info("WebDriver closed successfully")
            except Exception as e:
                logger.warning(f"Error closing WebDriver: {e}")
            finally:
                self.driver = None
                self.wait = None

    def _validate_element_structure(self, element: WebElement) -> Optional[str]:
        """Validate element structure and return insurance name if valid."""
        try:
            first_div = element.find_element(By.XPATH, "./div[1]")
            if not first_div:
                return None

            name_div = first_div.find_element(By.XPATH, "./div[1]")
            if not name_div:
                return None

            # Use the same robust text extraction as safe_get_text
            name_text = name_div.text.strip() if name_div.text else ""
            if not name_text:
                text_content = name_div.get_attribute("textContent")
                if text_content:
                    name_text = text_content.strip()
            if not name_text:
                inner_text = name_div.get_attribute("innerText")
                if inner_text:
                    name_text = inner_text.strip()

            return name_text if name_text else None
        except NoSuchElementException:
            return None

    def _extract_all_divs(self, element: WebElement) -> tuple[str, list[str]]:
        """Extract insurance name and all other divs from element."""
        insurance_name = safe_get_text(
            element.find_element(By.XPATH, "./div[1]/div[1]")
        )

        all_divs = []
        div_index = 2
        while True:
            try:
                div_element = element.find_element(
                    By.XPATH, f"./div[1]/div[{div_index}]"
                )
                div_text = safe_get_text(div_element)
                if div_text and div_text != "Unknown":
                    all_divs.append(div_text)
                div_index += 1
            except NoSuchElementException:
                break

        return insurance_name, all_divs

    def _parse_address_fields(self, remaining_divs: list[str]) -> tuple[str, str, str]:
        """Parse address fields into building, street, and postal components."""
        building_fields = []
        street_fields = []
        postal_fields = []

        # First pass: classify all fields
        for field in remaining_divs:
            if self._is_url(field) or self._is_phone(field):
                continue

            if self._is_postal_code_component(field):
                postal_fields.append(field)
            elif self._has_building_indicators(field):
                building_fields.append(field)
            elif self._looks_like_street_address(field):
                street_fields.append(field)
            else:
                building_part, street_part = self._parse_building_and_street(field)
                if building_part != "Unknown":
                    building_fields.append(building_part)
                if street_part != "Unknown":
                    street_fields.append(street_part)

        # Second pass: extract building and street from combined fields
        final_building_parts = []
        final_street_parts = []

        for field in building_fields:
            building_part, street_part = (
                self._extract_building_and_street_from_combined(field)
            )
            if building_part != "Unknown":
                final_building_parts.append(building_part)
            if street_part != "Unknown":
                final_street_parts.append(street_part)

        final_street_parts.extend(street_fields)

        building_complex = (
            " ".join(final_building_parts) if final_building_parts else "Unknown"
        )
        street = " ".join(final_street_parts) if final_street_parts else "Unknown"
        postal_code_city = " ".join(postal_fields) if postal_fields else "Unknown"

        return building_complex, street, postal_code_city

    def _extract_url_and_phone(
        self, remaining_divs: list[str], postal_code_city: str
    ) -> tuple[str, str, str]:
        """Extract URL and phone from remaining fields."""
        url_text = "Unknown"
        phone_number = "Unknown"

        # Look for URL and phone in remaining fields
        remaining_fields = remaining_divs[2:] if len(remaining_divs) > 2 else []

        for field in remaining_fields:
            if url_text == "Unknown" and self._is_url(field):
                url_text = field
                break

        for field in remaining_fields:
            if phone_number == "Unknown" and self._is_phone(field):
                phone_number = field
                break

        # Check if phone is embedded in postal_code_city
        if phone_number == "Unknown" and postal_code_city != "Unknown":
            cleaned_postal, extracted_phone = self._extract_phone_from_address(
                postal_code_city
            )
            if extracted_phone != "Unknown":
                phone_number = extracted_phone
                postal_code_city = cleaned_postal

        return url_text, phone_number, postal_code_city

    def _map_fields_to_entity_data(self, all_divs: list[str]) -> dict[str, str]:
        """Map div fields to entity data fields."""
        if not all_divs:
            return {
                "group_name": "Unknown",
                "building_complex": "Unknown",
                "street": "Unknown",
                "postal_code_city": "Unknown",
                "url": "Unknown",
                "phone_number": "Unknown",
            }

        # Check if first field is a group name
        first_field = all_divs[0] if len(all_divs) > 0 else ""
        group_name = first_field if first_field.startswith("GROUPE") else "Unknown"
        remaining_divs = all_divs[1:] if first_field.startswith("GROUPE") else all_divs

        # Parse address fields
        if remaining_divs:
            building_complex, street, postal_code_city = self._parse_address_fields(
                remaining_divs
            )
            url_text, phone_number, postal_code_city = self._extract_url_and_phone(
                remaining_divs, postal_code_city
            )
        else:
            building_complex = "Unknown"
            street = "Unknown"
            postal_code_city = "Unknown"
            url_text = "Unknown"
            phone_number = "Unknown"

        return {
            "group_name": group_name,
            "building_complex": building_complex,
            "street": street,
            "postal_code_city": postal_code_city,
            "url": url_text,
            "phone_number": phone_number,
        }

    @retry_on_failure(max_attempts=3, delay=2.0)
    def _extract_entities_from_page(self, url: str) -> list[FranceAssureursEntity]:
        """Extract all entities from the France Assureurs page.

        Args:
            url: URL to scrape

        Returns:
            List of FranceAssureursEntity objects
        """
        assert self.driver is not None, "WebDriver not initialized"
        assert self.wait is not None, "WebDriverWait not initialized"

        logger.info(f"Navigating to: {url}")
        self.driver.get(url)

        # Wait for the content to load
        try:
            self.wait.until(
                EC.presence_of_element_located(
                    (
                        By.XPATH,
                        '//*[@id="who-block-adherents-fa-b1"]/div/div[2]/div/ul/li',
                    )
                )
            )
        except TimeoutException:
            logger.warning("Timeout waiting for content to load")
            return []

        entities = []

        # Find all list items containing entity data
        try:
            entity_elements = self.driver.find_elements(
                By.XPATH, '//*[@id="who-block-adherents-fa-b1"]/div/div[2]/div/ul/li'
            )
            logger.info(f"Found {len(entity_elements)} potential entities")

            for i, element in enumerate(entity_elements, 1):
                try:
                    # Validate element structure
                    if not self._validate_element_structure(element):
                        continue

                    # Extract insurance name and other divs
                    insurance_name, all_divs = self._extract_all_divs(element)

                    # Map fields to entity data
                    field_data = self._map_fields_to_entity_data(all_divs)

                    # Create entity if valid
                    if (
                        insurance_name
                        and insurance_name != "Unknown"
                        and len(insurance_name.strip()) > 0
                    ):
                        entity = FranceAssureursEntity(
                            insurance_name=insurance_name,
                            group_name=field_data["group_name"],
                            building_complex=field_data["building_complex"],
                            street=field_data["street"],
                            postal_code_city=field_data["postal_code_city"],
                            url=field_data["url"],
                            phone_number=field_data["phone_number"],
                        )
                        entities.append(entity)
                        logger.debug(
                            f"Successfully extracted entity {len(entities)}: {insurance_name}"
                        )

                except (NoSuchElementException, TimeoutException) as e:
                    logger.debug(f"Could not extract entity {i}: {e}")
                    continue

        except NoSuchElementException:
            logger.warning("No entity elements found on the page")

        return entities

    def _is_url(self, text: str) -> bool:
        """Determine if a text field is a URL based on content patterns."""
        if not text or text == "Unknown":
            return False
        text_lower = text.lower()
        # Check for common URL patterns
        url_indicators = [
            "www.",
            "http://",
            "https://",
            ".com",
            ".fr",
            ".org",
            ".net",
            ".eu",
        ]
        return any(indicator in text_lower for indicator in url_indicators)

    def _is_phone(self, text: str) -> bool:
        """Determine if a text field is a phone number based on content patterns."""
        if not text or text == "Unknown":
            return False
        # Remove spaces and common separators for analysis
        text_clean = (
            text.replace(" ", "")
            .replace("-", "")
            .replace(".", "")
            .replace("(", "")
            .replace(")", "")
        )

        # Check for phone number patterns
        if len(text_clean) < 8:  # Too short to be a phone number
            return False

        # Count digits in the text
        digit_count = sum(1 for c in text_clean if c.isdigit())

        # French phone patterns:
        # - Starts with 0 (domestic) or +33 (international) or +596 (overseas territories)
        # - Contains at least 8 digits
        # - Length is appropriate for phone number (8-15 characters after cleaning)
        phone_indicators = [
            text_clean.startswith("0") and digit_count >= 9,  # 0XXXXXXXXX (10 digits)
            text_clean.startswith("+33") and digit_count >= 9,  # +33XXXXXXXXX
            text_clean.startswith("+596")
            and digit_count >= 9,  # +596XXXXXXXXX (overseas)
            text_clean.startswith("+")
            and digit_count >= 8,  # Other international formats
        ]

        # Additional check: if it's mostly digits and has phone-like length
        if digit_count >= 8 and len(text_clean) <= 15:
            digit_ratio = digit_count / len(text_clean)
            if digit_ratio >= 0.7:  # At least 70% digits
                return True

        return any(phone_indicators)

    def _extract_phone_from_address(self, text: str) -> tuple[str, str]:
        """Extract phone number from address field if present, return (cleaned_address, phone)."""
        if not text or text == "Unknown":
            return text, "Unknown"

        # Look for phone patterns at the end of address fields
        phone_patterns = [
            r"(\+\d{10,15})$",  # International format at end
            r"(0\d{9,12})$",  # French domestic format at end
            r"(\+596\d{9})$",  # Overseas territories at end
        ]

        for pattern in phone_patterns:
            match = re.search(pattern, text.replace(" ", ""))
            if match:
                phone = match.group(1)
                # Remove the phone from the address
                address_part = text[: match.start()].strip()
                return address_part, phone

        return text, "Unknown"

    def _has_building_indicators(self, field: str) -> bool:
        """Check if a field contains building/complex indicators.

        Args:
            field: Field text to check

        Returns:
            True if field appears to contain building information
        """
        if not field or field == "Unknown":
            return False

        field_lower = field.lower()
        building_indicators = [
            "tour ",
            "immeuble ",
            "bâtiment ",
            "résidence ",
            "centre ",
            "complex",
            "parc ",
            "espace ",
            "pôle ",
            "zone ",
            "quartier ",
            "esplanade ",
            "terrasse",
            "étage",
        ]

        return any(indicator in field_lower for indicator in building_indicators)

    def _looks_like_street_address(self, field: str) -> bool:
        """Check if a field looks like a street address.

        Args:
            field: Field text to check

        Returns:
            True if field appears to be a street address
        """
        if not field or field == "Unknown":
            return False

        field_lower = field.lower()

        # Common street indicators in French addresses
        street_indicators = [
            "rue ",
            "avenue ",
            "boulevard ",
            "place ",
            "cours ",
            "quai ",
            "impasse ",
            "allée ",
            "chemin ",
            "square ",
            "passage ",
            "promenade ",
            "parvis ",
            "terrasse ",
        ]

        # Check if it starts with a number (common for street addresses)

        if re.match(r"^\d+", field.strip()):
            return True

        return any(indicator in field_lower for indicator in street_indicators)

    def _extract_building_and_street_from_combined(self, field: str) -> tuple[str, str]:
        """Extract building and street components from a combined field.

        Args:
            field: Combined field containing building and potentially street info

        Returns:
            Tuple of (building_part, street_part)
        """
        if not field or field == "Unknown":
            return "Unknown", "Unknown"

        # Pattern for extracting street addresses (number + street name)
        street_pattern = r"\b\d+\s+(?:rue|avenue|boulevard|place|cours|quai|impasse|allée|chemin|square|passage|promenade|parvis|terrasse)\s+[^,]*"

        # Find street addresses in the field
        street_matches = re.findall(street_pattern, field, re.IGNORECASE)

        if street_matches:
            # Take the first street match
            street_part = street_matches[0].strip()
            # Remove the street part from the original to get building part
            building_part = field.replace(street_part, "").strip()
            # Clean up building part (remove extra spaces, leading/trailing separators)
            building_part = re.sub(r"\s*[-–,]\s*$", "", building_part).strip()
            building_part = re.sub(r"^\s*[-–,]\s*", "", building_part).strip()

            if not building_part:
                building_part = "Unknown"
            if not street_part:
                street_part = "Unknown"

            return building_part, street_part
        # No street found, treat entire field as building
        return field, "Unknown"

    def _is_postal_code_component(self, field: str) -> bool:
        """Check if a field is a postal code component like TSA, CS codes.

        Args:
            field: Field text to check

        Returns:
            True if field appears to be a postal code component
        """
        if not field or field == "Unknown":
            return False

        field = field.strip()

        # Common postal code prefixes in France
        postal_prefixes = ["TSA", "CS", "BP", "Cedex", "CEDEX"]

        # Check if field starts with postal prefix
        for prefix in postal_prefixes:
            if field.startswith(prefix):
                return True

        # Check if field looks like postal code + city (5 digits followed by uppercase letters and optional hyphens)

        if re.match(r"^\d{5}\s+[A-Z\s\-]+", field):
            return True

        # Check if it's just "Cedex" or similar postal suffixes
        postal_suffixes = [
            "cedex",
            "cedex 01",
            "cedex 02",
            "cedex 03",
            "cedex 04",
            "cedex 05",
            "cedex 06",
            "cedex 07",
            "cedex 08",
            "cedex 09",
            "cedex 10",
            "cedex 11",
            "cedex 12",
            "cedex 13",
            "cedex 14",
            "cedex 15",
            "cedex 16",
            "cedex 17",
        ]

        return field.lower().strip() in postal_suffixes

    def _parse_building_and_street(self, address_text: str) -> tuple[str, str]:
        """Parse building/complex name from street address.

        Args:
            address_text: Raw address field containing building and street info

        Returns:
            Tuple of (building_complex, street_address)
        """
        if not address_text or address_text == "Unknown":
            return "Unknown", "Unknown"

        # Common building/complex indicators in French addresses
        building_indicators = [
            "Tour ",
            "Immeuble ",
            "Bâtiment ",
            "Résidence ",
            "Centre ",
            "Complex",
            "Parc ",
            "Espace ",
            "Pôle ",
            "Zone ",
            "Quartier ",
            "Esplanade ",
        ]

        # Split on common address separators
        separators = [" – ", " - ", ", ", " | "]
        parts = [address_text]

        # Split the address using any of the separators
        for separator in separators:
            new_parts = []
            for part in parts:
                new_parts.extend(part.split(separator))
            parts = new_parts

        # Clean up parts
        parts = [part.strip() for part in parts if part.strip()]

        if len(parts) == 1:
            # Single part - check if it looks like a building or street
            single_part = parts[0]
            if any(
                single_part.startswith(indicator) for indicator in building_indicators
            ):
                return single_part, "Unknown"
            return "Unknown", single_part

        if len(parts) >= 2:
            # Multiple parts - identify building vs street
            building_parts = []
            street_parts = []

            for part in parts:
                # Check if this part looks like a building/complex
                if any(part.startswith(indicator) for indicator in building_indicators):
                    building_parts.append(part)
                else:
                    # Check if it looks like a street address (contains numbers and street indicators)
                    street_indicators = [
                        "rue ",
                        "avenue ",
                        "boulevard ",
                        "place ",
                        "cours ",
                        "chemin ",
                        "allée ",
                    ]
                    is_street = any(
                        indicator in part.lower() for indicator in street_indicators
                    )

                    # Also check for address-like patterns (starts with number)

                    starts_with_number = re.match(r"^\d+", part.strip())

                    if is_street or starts_with_number:
                        street_parts.append(part)
                    # If we already have building parts, this is probably more building info
                    # Otherwise, it might be street info
                    elif building_parts:
                        building_parts.append(part)
                    else:
                        street_parts.append(part)

            # Combine parts
            building_complex = (
                " – ".join(building_parts) if building_parts else "Unknown"
            )
            street_address = " – ".join(street_parts) if street_parts else "Unknown"

            return building_complex, street_address

        return "Unknown", "Unknown"

    def scrape_url(self, url: str) -> list[FranceAssureursEntity]:
        """Scrape insurance entities from France Assureurs website.

        Args:
            url: Target URL to scrape

        Returns:
            List of FranceAssureursEntity objects

        Raises:
            WebDriverException: If there are issues with browser automation
            TimeoutException: If page loading times out
            ValueError: If URL is invalid
        """
        if not validate_url(url):
            raise ValueError(f"Invalid URL provided: {url}")

        if not self.driver:
            self._setup_driver()

        start_time = time.time()
        errors_count = 0

        try:
            logger.info("Starting France Assureurs scraping...")

            # Apply rate limiting
            self.rate_limiter.wait_if_needed()

            # Extract entity data from the page
            entities = self._extract_entities_from_page(url)

            # Log scraping statistics
            log_scraping_stats(len(entities), start_time, url, errors_count)

            return entities

        except Exception as e:
            errors_count += 1
            logger.error(f"Error scraping URL {url}: {e}")
            raise

    def __enter__(self) -> FranceAssureursScraper:
        """Context manager entry."""
        self._setup_driver()
        return self

    def __exit__(self, _exc_type: object, _exc_val: object, _exc_tb: object) -> None:
        """Context manager exit."""
        self._teardown_driver()


def scrape_fitch_insurance_entities(
    url: str,
    headless: bool = True,
    timeout: int = 10,
    rate_limit: float = 2.0,
    max_pages: int = 10,
) -> list[dict[str, object]]:
    """Convenience function to scrape insurance entities.

    Args:
        url: Target URL to scrape
        headless: Whether to run browser in headless mode
        timeout: WebDriver timeout in seconds
        rate_limit: Minimum interval between requests in seconds
        max_pages: Maximum number of pages to scrape

    Returns:
        List of dictionaries containing entity data
    """
    with FitchRatingsScraper(
        headless=headless, timeout=timeout, rate_limit=rate_limit, max_pages=max_pages
    ) as scraper:
        entities = scraper.scrape_url(url)
        return [asdict(entity) for entity in entities]


def scrape_hatvp_entities(
    url: str,
    headless: bool = True,
    timeout: int = 10,
    rate_limit: float = 2.0,
) -> list[dict[str, object]]:
    """Convenience function to scrape HATVP entities.

    Args:
        url: Target URL to scrape
        headless: Whether to run browser in headless mode
        timeout: WebDriver timeout in seconds
        rate_limit: Minimum interval between requests in seconds

    Returns:
        List of dictionaries containing entity data
    """
    with HATVPScraper(
        headless=headless,
        timeout=timeout,
        rate_limit=rate_limit,
    ) as scraper:
        entities = scraper.scrape_url(url)
        return [asdict(entity) for entity in entities]


def scrape_france_assureurs_entities(
    url: str,
    headless: bool = True,
    timeout: int = 10,
    rate_limit: float = 2.0,
) -> list[dict[str, object]]:
    """Convenience function to scrape France Assureurs entities.

    Args:
        url: Target URL to scrape
        headless: Whether to run browser in headless mode
        timeout: WebDriver timeout in seconds
        rate_limit: Minimum interval between requests in seconds

    Returns:
        List of dictionaries containing entity data
    """
    with FranceAssureursScraper(
        headless=headless,
        timeout=timeout,
        rate_limit=rate_limit,
    ) as scraper:
        entities = scraper.scrape_url(url)
        return [asdict(entity) for entity in entities]


class ABEScraper:
    """Scraper for extracting blacklist entity data from ABE Info Service."""

    def __init__(
        self,
        headless: bool = True,
        timeout: int = 10,
        rate_limit: float = 2.0,
        max_pages: int = 100,
    ) -> None:
        """Initialize the scraper with WebDriver configuration.

        Args:
            headless: Whether to run browser in headless mode
            timeout: Timeout in seconds for WebDriver waits
            rate_limit: Minimum interval between requests in seconds
            max_pages: Maximum number of pages to scrape
        """
        self.headless = headless
        self.timeout = timeout
        self.max_pages = max_pages
        self.driver: Optional[WebDriver] = None
        self.wait: Optional[WebDriverWait[WebDriver]] = None
        self.rate_limiter = RateLimiter(rate_limit)

        # XPath templates from XPATHs_ABE.md
        self.table_row_xpath_template = '//*[@id="block-bdf-abeis-content"]/div/div/div/div[3]/div[2]/table/tbody/tr[X]'
        self.url_mail_name_xpath_template = '//*[@id="block-bdf-abeis-content"]/div/div/div/div[3]/div[2]/table/tbody/tr[X]/td[1]/div/div'
        self.denomination_xpath_template = '//*[@id="block-bdf-abeis-content"]/div/div/div/div[3]/div[2]/table/tbody/tr[X]/td[2]/div/div'
        self.category_xpath_template = '//*[@id="block-bdf-abeis-content"]/div/div/div/div[3]/div[2]/table/tbody/tr[X]/td[3]/div/div'
        self.date_added_xpath_template = '//*[@id="block-bdf-abeis-content"]/div/div/div/div[3]/div[2]/table/tbody/tr[X]/td[4]/div/div'

        # End of pages detection XPath
        self.end_of_pages_xpath = (
            '//*[@id="block-bdf-abeis-content"]/div/div/div/div[3]'
        )

    def _setup_driver(self) -> None:
        """Set up Chrome WebDriver with appropriate options."""
        try:
            logger.info("Attempting to initialize Chrome WebDriver...")

            chrome_options = ChromeOptions()
            if self.headless:
                chrome_options.add_argument("--headless")

            chrome_options.add_argument("--no-sandbox")
            chrome_options.add_argument("--disable-dev-shm-usage")
            chrome_options.add_argument("--disable-gpu")
            chrome_options.add_argument("--window-size=1920,1080")

            try:
                # Try system ChromeDriver first
                service = ChromeService("/usr/bin/chromedriver")
                self.driver = webdriver.Chrome(service=service, options=chrome_options)
                logger.info("Using system ChromeDriver")
            except Exception:
                # Fallback to webdriver-manager
                try:
                    service = ChromeService(ChromeDriverManager().install())
                    self.driver = webdriver.Chrome(
                        service=service, options=chrome_options
                    )
                    logger.info("Using webdriver-manager ChromeDriver")
                except Exception as e:
                    logger.error(f"Chrome WebDriver initialization failed: {e}")
                    raise WebDriverException(
                        f"Could not initialize Chrome WebDriver: {e}"
                    ) from e

            self.wait = WebDriverWait(self.driver, self.timeout)
            logger.info("Chrome WebDriver initialized successfully")

        except Exception as e:
            logger.error(f"Failed to set up WebDriver: {e}")
            if self.driver:
                self.driver.quit()
                self.driver = None
            raise

    def _teardown_driver(self) -> None:
        """Clean up WebDriver resources."""
        if self.driver:
            try:
                self.driver.quit()
                logger.info("WebDriver closed successfully")
            except Exception as e:
                logger.warning(f"Error closing WebDriver: {e}")
            finally:
                self.driver = None
                self.wait = None

    def __enter__(self) -> ABEScraper:
        """Context manager entry."""
        self._setup_driver()
        return self

    def __exit__(self, _exc_type: object, _exc_val: object, _exc_tb: object) -> None:
        """Context manager exit."""
        self._teardown_driver()

    def _check_end_of_pages(self) -> bool:
        """Check if we've reached the end of pages.

        Returns:
            True if no more pages available
        """
        assert self.wait is not None, "WebDriverWait not initialized"

        try:
            end_element = self.wait.until(
                EC.presence_of_element_located((By.XPATH, self.end_of_pages_xpath))
            )
            content = safe_get_text(end_element)
            if "Aucun resultat pour cette page" in content:
                logger.info("Reached end of pages: no results found")
                return True
            return False
        except (TimeoutException, NoSuchElementException):
            # If we can't find the end element, assume we're not at the end
            return False

    @retry_on_failure(max_attempts=3, delay=2.0)
    def _extract_entities_from_page(self) -> list[ABEEntity]:
        """Extract all entities from the current page."""
        assert self.driver is not None, "WebDriver not initialized"
        assert self.wait is not None, "WebDriverWait not initialized"

        entities: list[ABEEntity] = []
        row_index = 1

        while True:
            try:
                # Generate XPath for current row
                row_xpath = self.table_row_xpath_template.replace(
                    "[X]", f"[{row_index}]"
                )

                # Check if row exists
                self.wait.until(EC.presence_of_element_located((By.XPATH, row_xpath)))

                # Extract data from each column
                url_mail_name_xpath = self.url_mail_name_xpath_template.replace(
                    "[X]", f"[{row_index}]"
                )
                denomination_xpath = self.denomination_xpath_template.replace(
                    "[X]", f"[{row_index}]"
                )
                category_xpath = self.category_xpath_template.replace(
                    "[X]", f"[{row_index}]"
                )
                date_added_xpath = self.date_added_xpath_template.replace(
                    "[X]", f"[{row_index}]"
                )

                try:
                    url_mail_element = self.driver.find_element(
                        By.XPATH, url_mail_name_xpath
                    )
                    url_mail_name = safe_get_text(url_mail_element)
                except (TimeoutException, NoSuchElementException):
                    url_mail_name = ""

                try:
                    denomination_element = self.driver.find_element(
                        By.XPATH, denomination_xpath
                    )
                    denomination = safe_get_text(denomination_element)
                except (TimeoutException, NoSuchElementException):
                    denomination = ""

                try:
                    category_element = self.driver.find_element(
                        By.XPATH, category_xpath
                    )
                    category = safe_get_text(category_element)
                except (TimeoutException, NoSuchElementException):
                    category = ""

                try:
                    date_added_element = self.driver.find_element(
                        By.XPATH, date_added_xpath
                    )
                    date_added = safe_get_text(date_added_element)
                except (TimeoutException, NoSuchElementException):
                    date_added = ""

                # Create entity if we have at least some data
                if url_mail_name or denomination or category or date_added:
                    entity = ABEEntity(
                        url_mail_name=url_mail_name,
                        denomination=denomination,
                        category=category,
                        date_added=date_added,
                    )
                    entities.append(entity)
                    logger.debug(f"Extracted entity {row_index}: {entity}")

                row_index += 1

            except (TimeoutException, NoSuchElementException):
                # No more rows found
                break
            except Exception as e:
                logger.warning(f"Error extracting row {row_index}: {e}")
                break

        logger.info(f"Extracted {len(entities)} entities from current page")
        return entities

    def scrape_url(self, url_template: str) -> list[ABEEntity]:
        """Scrape ABE entities from paginated results.

        Args:
            url_template: URL template with 'N' placeholder for page number

        Returns:
            List of ABEEntity objects
        """
        if not validate_url(url_template):
            raise ValueError(f"Invalid URL provided: {url_template}")

        if not self.driver:
            raise RuntimeError(
                "WebDriver not initialized. Use context manager or call _setup_driver()"
            )

        all_entities: list[ABEEntity] = []
        page_number = 0
        errors_count = 0
        start_time = time.time()

        while page_number < self.max_pages:
            try:
                current_url = url_template.replace("N", str(page_number))
                logger.info(f"Scraping page {page_number}: {current_url}")

                # Rate limiting
                self.rate_limiter.wait_if_needed()

                # Navigate to page
                self.driver.get(current_url)

                # Check if we've reached the end of pages
                if self._check_end_of_pages():
                    logger.info(f"No more results found at page {page_number}")
                    break

                # Extract entities from current page
                entities = self._extract_entities_from_page()
                if not entities:
                    logger.info(f"No entities found on page {page_number}")
                    break

                all_entities.extend(entities)
                page_number += 1

            except Exception as e:
                logger.error(f"Error scraping page {page_number}: {e}")
                errors_count += 1
                break

        logger.info(f"Scraping completed. Total entities found: {len(all_entities)}")

        # Log scraping statistics
        log_scraping_stats(len(all_entities), start_time, url_template, errors_count)

        return all_entities


def scrape_abe_entities(
    url: str,
    headless: bool = True,
    timeout: int = 10,
    rate_limit: float = 2.0,
    max_pages: int = 100,
) -> list[dict[str, object]]:
    """Convenience function to scrape ABE blacklist entities.

    Args:
        url: Target URL template with 'N' placeholder for page number
        headless: Whether to run browser in headless mode
        timeout: WebDriver timeout in seconds
        rate_limit: Minimum interval between requests in seconds
        max_pages: Maximum number of pages to scrape

    Returns:
        List of dictionaries containing entity data
    """
    with ABEScraper(
        headless=headless, timeout=timeout, rate_limit=rate_limit, max_pages=max_pages
    ) as scraper:
        entities = scraper.scrape_url(url)
        return [asdict(entity) for entity in entities]
