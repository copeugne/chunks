"""Data export utilities for insurance entity data."""

import csv
import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, Union

logger = logging.getLogger(__name__)


class DataExporter:
    """Handles exporting scraped data to various formats."""

    def __init__(self, output_dir: str = "output") -> None:
        """Initialize exporter with output directory.

        Args:
            output_dir: Directory to save exported files
        """
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)

    def _generate_filename(self, format_type: str, data_type: str = "entities") -> str:
        """Generate timestamp-based filename.

        Args:
            format_type: File format (csv, json)
            data_type: Type of data (used in filename prefix)

        Returns:
            Generated filename with timestamp
        """
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        return f"{data_type}_{timestamp}.{format_type}"

    def export_to_csv(
        self,
        data: list[dict[str, object]],
        filename: Optional[str] = None,
        include_stats: bool = False,
        website: str = "fitch",
    ) -> Path:
        """Export data to CSV format.

        Args:
            data: List of dictionaries containing entity data
            filename: Optional custom filename
            include_stats: Whether to include summary statistics
            website: Website source for data-specific handling

        Returns:
            Path to the exported CSV file

        Raises:
            ValueError: If data is empty
            IOError: If file writing fails
        """
        if not data:
            raise ValueError("Cannot export empty data to CSV")

        if filename is None:
            filename = self._generate_filename("csv", f"{website}_entities")

        output_path = self.output_dir / filename

        try:
            with output_path.open("w", newline="", encoding="utf-8") as csvfile:
                # Get fieldnames from first record
                fieldnames = list(data[0].keys())
                writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

                writer.writeheader()
                writer.writerows(data)

                # Add summary statistics if requested
                if include_stats:
                    self._write_csv_statistics(writer, data, fieldnames, website)

            logger.info(
                f"Successfully exported {len(data)} entities to CSV: {output_path}"
            )
            return output_path

        except OSError as e:
            logger.error(f"Failed to write CSV file {output_path}: {e}")
            raise

    def _write_csv_statistics(
        self,
        writer: csv.DictWriter[str],
        data: list[dict[str, object]],
        fieldnames: list[str],
        website: str,
    ) -> None:
        """Write statistics to CSV based on data type.

        Args:
            writer: CSV DictWriter object
            data: List of dictionaries containing entity data
            fieldnames: List of field names
            website: Website source for data-specific statistics
        """
        # Determine the primary name field for statistics display
        if "entity_name" in fieldnames:
            name_field = "entity_name"
        elif "insurance_name" in fieldnames:
            name_field = "insurance_name"
        elif "url_mail_name" in fieldnames:
            name_field = "url_mail_name"
        else:
            name_field = next(iter(fieldnames))  # Use first field as fallback

        total_entities = len(data)

        # Write basic statistics
        writer.writerow({})  # Empty row separator
        writer.writerow({name_field: "=== SUMMARY STATISTICS ==="})
        writer.writerow({name_field: f"Total Entities: {total_entities}"})

        if website == "fitch":
            # Fitch-specific statistics
            unique_sectors: set[str] = set()
            unique_countries: set[str] = set()

            for entity in data:
                sector = str(entity.get("sector", ""))
                country = str(entity.get("country", ""))

                if sector and sector != "Unknown":
                    unique_sectors.add(sector)
                if country and country != "Unknown":
                    unique_countries.add(country)

            writer.writerow({name_field: f"Unique Sectors: {len(unique_sectors)}"})
            writer.writerow({name_field: f"Unique Countries: {len(unique_countries)}"})

            writer.writerow({})  # Empty row separator
            writer.writerow({name_field: "Top Sectors:"})
            for sector in sorted(unique_sectors):
                writer.writerow({name_field: f"  - {sector}"})

            writer.writerow({})  # Empty row separator
            writer.writerow({name_field: "Top Countries:"})
            for country in sorted(unique_countries):
                writer.writerow({name_field: f"  - {country}"})

        elif website == "franceassureurs":
            # France Assureurs-specific statistics
            unique_groups: set[str] = set()
            for entity in data:
                group = str(entity.get("group_name", ""))
                if group and group != "Unknown":
                    unique_groups.add(group)

            writer.writerow({name_field: f"Unique Groups: {len(unique_groups)}"})

            writer.writerow({})  # Empty row separator
            writer.writerow({name_field: "Top Groups:"})
            for group in sorted(unique_groups):
                writer.writerow({name_field: f"  - {group}"})

        elif website == "abe":
            # ABE-specific statistics
            unique_categories: set[str] = set()
            for entity in data:
                category = str(entity.get("category", ""))
                if category and category != "Unknown":
                    unique_categories.add(category)

            writer.writerow(
                {name_field: f"Unique Categories: {len(unique_categories)}"}
            )

            writer.writerow({})  # Empty row separator
            writer.writerow({name_field: "Top Categories:"})
            for category in sorted(unique_categories):
                writer.writerow({name_field: f"  - {category}"})

    def export_to_json(
        self,
        data: list[dict[str, object]],
        filename: Optional[str] = None,
        indent: int = 2,
        include_stats: bool = False,
        website: str = "fitch",
    ) -> Path:
        """Export data to JSON format.

        Args:
            data: List of dictionaries containing entity data
            filename: Optional custom filename
            indent: JSON indentation level
            include_stats: Whether to include summary statistics
            website: Website source for data-specific handling

        Returns:
            Path to the exported JSON file

        Raises:
            ValueError: If data is empty
            IOError: If file writing fails
        """
        if not data:
            raise ValueError("Cannot export empty data to JSON")

        if filename is None:
            filename = self._generate_filename("json", f"{website}_entities")

        output_path = self.output_dir / filename

        # Generate metadata based on website
        source_map = {
            "fitch": "Fitch Ratings Insurance Entities",
            "franceassureurs": "France Assureurs Insurance Entities",
            "abe": "ABE Info Service Blacklist Entities",
        }

        export_data = {
            "metadata": {
                "export_timestamp": datetime.now(timezone.utc).isoformat(),
                "total_entities": len(data),
                "source": source_map.get(website, f"{website.title()} Entities"),
            },
            "entities": data,
        }

        # Add summary statistics if requested
        if include_stats:
            export_data["summary"] = self._generate_json_statistics(data, website)

        try:
            with output_path.open("w", encoding="utf-8") as jsonfile:
                json.dump(export_data, jsonfile, indent=indent, ensure_ascii=False)

            logger.info(
                f"Successfully exported {len(data)} entities to JSON: {output_path}"
            )
            return output_path

        except OSError as e:
            logger.error(f"Failed to write JSON file {output_path}: {e}")
            raise

    def _generate_json_statistics(
        self, data: list[dict[str, object]], website: str
    ) -> dict[str, Union[int, list[str]]]:
        """Generate JSON statistics based on data type.

        Args:
            data: List of dictionaries containing entity data
            website: Website source for data-specific statistics

        Returns:
            Dictionary containing statistics
        """
        stats: dict[str, Union[int, list[str]]] = {"total_entities": len(data)}

        if website == "fitch":
            # Fitch-specific statistics
            unique_sectors: set[str] = set()
            unique_countries: set[str] = set()

            for entity in data:
                sector = str(entity.get("sector", ""))
                country = str(entity.get("country", ""))

                if sector and sector != "Unknown":
                    unique_sectors.add(sector)
                if country and country != "Unknown":
                    unique_countries.add(country)

            stats.update(
                {
                    "unique_sectors_count": len(unique_sectors),
                    "unique_countries_count": len(unique_countries),
                    "sectors": sorted(unique_sectors),
                    "countries": sorted(unique_countries),
                }
            )

        elif website == "franceassureurs":
            # France Assureurs-specific statistics
            unique_groups: set[str] = set()
            for entity in data:
                group = str(entity.get("group_name", ""))
                if group and group != "Unknown":
                    unique_groups.add(group)

            stats.update(
                {
                    "unique_groups_count": len(unique_groups),
                    "groups": sorted(unique_groups),
                }
            )

        elif website == "abe":
            # ABE-specific statistics
            unique_categories: set[str] = set()
            for entity in data:
                category = str(entity.get("category", ""))
                if category and category != "Unknown":
                    unique_categories.add(category)

            stats.update(
                {
                    "unique_categories_count": len(unique_categories),
                    "categories": sorted(unique_categories),
                }
            )

        return stats

    def export_summary(
        self, data: list[dict[str, object]], filename: Optional[str] = None
    ) -> Path:
        """Export data summary statistics.

        Args:
            data: List of dictionaries containing entity data
            filename: Optional custom filename

        Returns:
            Path to the exported summary file

        Raises:
            ValueError: If data is empty
        """
        if not data:
            raise ValueError("Cannot generate summary for empty data")

        if filename is None:
            timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
            filename = f"fitch_summary_{timestamp}.txt"

        output_path = self.output_dir / filename

        # Generate summary statistics
        total_entities = len(data)
        unique_sectors: set[str] = set()
        unique_countries: set[str] = set()

        for entity in data:
            sector = str(entity.get("sector", ""))
            country = str(entity.get("country", ""))

            if sector and sector != "Unknown":
                unique_sectors.add(sector)
            if country and country != "Unknown":
                unique_countries.add(country)

        # Build detailed entity listing
        entity_details: list[str] = []
        for i, entity in enumerate(data, 1):
            entity_name = str(entity.get("entity_name", ""))
            sector_str = str(entity.get("sector", ""))
            country_str = str(entity.get("country", ""))
            url = str(entity.get("url", "N/A"))
            entity_details.append(
                f"{i:3d}. {entity_name:<50} | {sector_str:<20} | {country_str:<20} | {url}"
            )

        summary_text = f"""Fitch Ratings Insurance Entities Summary
Generated: {datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")}

=== STATISTICS ===
Total Entities: {total_entities}
Unique Sectors: {len(unique_sectors)}
Unique Countries: {len(unique_countries)}

Top Sectors:
{chr(10).join(f"  - {sector}" for sector in sorted(unique_sectors)[:10])}

Top Countries:
{chr(10).join(f"  - {country}" for country in sorted(unique_countries)[:10])}

=== DETAILED ENTITY LISTING ===
{"#":<3} {"Entity Name":<50} | {"Sector":<20} | {"Country":<20} | {"URL"}
{"-" * 120}
{chr(10).join(entity_details)}

=== END OF REPORT ===
Total Records: {total_entities}
"""

        try:
            with output_path.open("w", encoding="utf-8") as summaryfile:
                summaryfile.write(summary_text)

            logger.info(f"Successfully exported summary to: {output_path}")
            return output_path

        except OSError as e:
            logger.error(f"Failed to write summary file {output_path}: {e}")
            raise


def export_data(
    data: list[dict[str, object]],
    output_format: str = "csv",
    output_dir: str = "output",
    filename: Optional[str] = None,
    include_stats: bool = False,
    sort_country: bool = False,
    website: str = "fitch",
) -> Path:
    """Convenience function to export data in specified format.

    Args:
        data: List of dictionaries containing entity data
        output_format: Export format ('csv' or 'json')
        output_dir: Directory to save exported files
        filename: Optional custom filename
        include_stats: Whether to include summary statistics
        sort_country: Group by country and sort alphabetically within each country
        website: Website source ('fitch', 'franceassureurs', 'abe') for data-specific handling

    Returns:
        Path to the exported file

    Raises:
        ValueError: If output_format is not supported
    """
    # Apply sorting if requested
    if sort_country:
        # Check what type of data we have and sort accordingly
        if data and "country" in data[0]:
            # Fitch data: Sort by country first, then by entity name within each country
            data = sorted(
                data,
                key=lambda x: (
                    str(x.get("country", "")),
                    str(x.get("entity_name", "")),
                ),
            )
        elif data and "insurance_name" in data[0]:
            # France Assureurs data: Sort by insurance name (no country field)
            data = sorted(data, key=lambda x: str(x.get("insurance_name", "")))
        elif data and "url_mail_name" in data[0]:
            # ABE data: Sort by denomination (primary name field)
            data = sorted(data, key=lambda x: str(x.get("denomination", "")))
        else:
            # Fallback: sort by the first available name field
            for name_field in [
                "entity_name",
                "insurance_name",
                "url_mail_name",
                "denomination",
                "name",
            ]:
                if data and name_field in data[0]:
                    data = sorted(data, key=lambda x: str(x.get(name_field, "")))
                    break

    exporter = DataExporter(output_dir)

    if output_format.lower() == "csv":
        return exporter.export_to_csv(data, filename, include_stats, website)
    if output_format.lower() == "json":
        return exporter.export_to_json(
            data, filename, include_stats=include_stats, website=website
        )
    raise ValueError(f"Unsupported output format: {output_format}")
