"""Utility functions for the insurance scraper."""

import logging
import time
from functools import wraps
from typing import Callable, Optional, TypeVar, cast

from selenium.common.exceptions import TimeoutException, WebDriverException
from selenium.webdriver.remote.webelement import WebElement

logger = logging.getLogger(__name__)

F = TypeVar("F", bound=Callable[..., object])


def retry_on_failure(
    max_attempts: int = 3,
    delay: float = 1.0,
    backoff_factor: float = 2.0,
    exceptions: tuple[type[BaseException], ...] = (
        WebDriverException,
        TimeoutException,
    ),
) -> Callable[[F], F]:
    """Decorator to retry function calls on specified exceptions.

    Args:
        max_attempts: Maximum number of retry attempts
        delay: Initial delay between retries in seconds
        backoff_factor: Factor to multiply delay by after each failure
        exceptions: Tuple of exception types to catch and retry on

    Returns:
        Decorated function with retry logic
    """

    def decorator(func: F) -> F:
        @wraps(func)
        def wrapper(*args: object, **kwargs: object) -> object:
            current_delay = delay

            for attempt in range(max_attempts):
                try:
                    return func(*args, **kwargs)
                except exceptions as e:
                    if attempt == max_attempts - 1:
                        logger.error(
                            f"Function {func.__name__} failed after "
                            f"{max_attempts} attempts: {e}"
                        )
                        raise

                    logger.warning(
                        f"Attempt {attempt + 1} failed for {func.__name__}: {e}. "
                        f"Retrying in {current_delay:.1f} seconds..."
                    )
                    time.sleep(current_delay)
                    current_delay *= backoff_factor

            raise RuntimeError(f"Retry logic failed for {func.__name__}")

        return cast(F, wrapper)

    return decorator


class RateLimiter:
    """Rate limiter to control request frequency."""

    def __init__(self, min_interval: float = 1.0) -> None:
        """Initialize rate limiter.

        Args:
            min_interval: Minimum interval between requests in seconds
        """
        self.min_interval = min_interval
        self.last_request_time: Optional[float] = None

    def wait_if_needed(self) -> None:
        """Wait if necessary to maintain minimum interval between requests."""
        current_time = time.time()

        if self.last_request_time is not None:
            elapsed = current_time - self.last_request_time
            if elapsed < self.min_interval:
                sleep_time = self.min_interval - elapsed
                logger.debug(f"Rate limiting: sleeping for {sleep_time:.2f} seconds")
                time.sleep(sleep_time)

        self.last_request_time = time.time()


def safe_get_text(element: Optional[WebElement], default: str = "Unknown") -> str:
    """Safely extract text from a WebElement.

    Args:
        element: Selenium WebElement or None
        default: Default value if text extraction fails

    Returns:
        Element text or default value (cleaned of newlines)
    """
    try:
        if element is None:
            return default

        # Try multiple methods to get text content
        text = element.text.strip()
        if not text:
            # Fallback to textContent if .text is empty
            text_content = element.get_attribute("textContent")
            if text_content:
                text = text_content.strip()
        if not text:
            # Fallback to innerText if textContent is also empty
            inner_text = element.get_attribute("innerText")
            if inner_text:
                text = inner_text.strip()

        if text:
            # Replace multiple newlines and whitespace with single spaces
            return " ".join(text.split())
        return default
    except Exception as e:
        logger.debug(f"Error extracting text from element: {e}")
        return default


def safe_get_attribute(
    element: Optional[WebElement], attribute: str, default: Optional[str] = None
) -> Optional[str]:
    """Safely extract attribute from a WebElement.

    Args:
        element: Selenium WebElement or None
        attribute: Attribute name to extract
        default: Default value if attribute extraction fails

    Returns:
        Element attribute value or default value
    """
    try:
        if element is None:
            return default
        attr_value = element.get_attribute(attribute)
        return attr_value if attr_value is not None else default
    except Exception as e:
        logger.debug(f"Error extracting attribute '{attribute}' from element: {e}")
        return default


def validate_url(url: Optional[str]) -> bool:
    """Validate if URL is properly formed.

    Args:
        url: URL to validate

    Returns:
        True if URL is valid, False otherwise
    """
    try:
        if not url or not isinstance(url, str):
            return False

        url = url.strip()
        if not url.startswith(("http://", "https://")):
            return False

        # Basic validation - could be more comprehensive
        valid_domains = [
            "fitchratings.com",
            "franceassureurs.fr",
            "abe-infoservice.fr",
            "hatvp.fr",
        ]
        return any(domain in url for domain in valid_domains) and len(url) > 20

    except Exception:
        return False


def parse_sector_country(sector_country_text: str) -> tuple[str, str]:
    """Parse sector and country from combined text.

    Args:
        sector_country_text: Combined sector and country text

    Returns:
        Tuple of (sector, country)
    """
    if not sector_country_text or sector_country_text == "Unknown":
        return "Unknown", "Unknown"

    # Clean the text
    cleaned_text = " ".join(sector_country_text.split())

    # Common patterns to split sector and country
    # Pattern 1: "Insurance United Kingdom" -> "Insurance", "United Kingdom"
    # Pattern 2: "Reinsurance, Germany" -> "Reinsurance", "Germany"
    # Pattern 3: "Insurance - France" -> "Insurance", "France"

    # Try comma separation first
    if "," in cleaned_text:
        parts = [part.strip() for part in cleaned_text.split(",")]
        if len(parts) >= 2:
            sector = parts[0]
            country = ", ".join(parts[1:])  # In case country has commas
            return sector, country

    # Try dash separation
    if " - " in cleaned_text:
        parts = [part.strip() for part in cleaned_text.split(" - ")]
        if len(parts) >= 2:
            sector = parts[0]
            country = " - ".join(parts[1:])
            return sector, country

    # For patterns like "Insurance United Kingdom", try to identify country
    # Common country patterns (this is a simplified approach)
    country_patterns = [
        "United Kingdom",
        "United States",
        "United Arab Emirates",
        "New Zealand",
        "South Africa",
        "Saudi Arabia",
        "Costa Rica",
        "Sri Lanka",
        "Puerto Rico",
        "Czech Republic",
        "South Korea",
        "North Korea",
        "El Salvador",
        "Dominican Republic",
    ]

    # Check for multi-word countries first
    for country in country_patterns:
        if country in cleaned_text:
            sector = cleaned_text.replace(country, "").strip()
            return sector, country

    # Try single-word countries (split by last word)
    words = cleaned_text.split()
    if len(words) >= 2:
        # Assume last word is country, rest is sector
        country = words[-1]
        sector = " ".join(words[:-1])

        # Simple validation: country should be capitalized
        if country[0].isupper():
            return sector, country

    # If we can't split it, assume it's all sector
    return cleaned_text, "Unknown"


def log_scraping_stats(
    entities_count: int, start_time: float, url: str, errors_count: int = 0
) -> None:
    """Log scraping statistics.

    Args:
        entities_count: Number of entities scraped
        start_time: Start time of scraping (from time.time())
        url: URL that was scraped
        errors_count: Number of errors encountered
    """
    duration = time.time() - start_time

    logger.info(
        f"Scraping completed - URL: {url[:50]}... | "
        f"Entities: {entities_count} | "
        f"Duration: {duration:.2f}s | "
        f"Errors: {errors_count}"
    )
