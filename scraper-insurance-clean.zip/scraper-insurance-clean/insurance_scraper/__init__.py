"""Insurance Scraper package for extracting data from Fitch Ratings."""

__version__ = "0.1.0"
