"""Command-line interface for the insurance scraper."""

import argparse
import logging
import sys
from pathlib import Path

from .exporter import export_data
from .scraper import (
    scrape_abe_entities,
    scrape_fitch_insurance_entities,
    scrape_france_assureurs_entities,
    scrape_hatvp_entities,
)


def setup_logging(verbose: bool = False) -> None:
    """Set up logging configuration.

    Args:
        verbose: Enable verbose (DEBUG) logging
    """
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s - %(levelname)s - %(message)s",
        handlers=[
            logging.FileHandler("scraper.log"),
            logging.StreamHandler(),
        ],
    )


def create_parser() -> argparse.ArgumentParser:
    """Create and configure the argument parser.

    Returns:
        Configured ArgumentParser instance
    """
    parser = argparse.ArgumentParser(
        description=(
            "Scrape entity data from Fitch Ratings, France Assureurs, "
            "ABE Info Service, or HATVP"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Basic usage with default URL from XPATHs.md (scrapes up to 10 pages)
  scrape-insurance

  # Scrape only 3 pages with JSON output
  scrape-insurance --max-pages 3 --format json

  # CSV output with summary statistics included
  scrape-insurance --format csv --stats --max-pages 5

  # JSON output with custom filename and summary
  scrape-insurance --format json --stats --filename my_results.json

  # CSV output sorted by country (alphabetical within each country)
  scrape-insurance --format csv --sort-country --max-pages 3

  # Scrape France Assureurs website with JSON output
  scrape-insurance --website franceassureurs --format json

  # Scrape ABE blacklist with CSV output and stats
  scrape-insurance --website abe --format csv --stats --max-pages 5

  # CSV output with custom filename and directory
  scrape-insurance --format csv --filename my_results.csv --output-dir /path/to/output

  # Scrape many pages with slower rate limiting, stats and country sorting
  scrape-insurance --max-pages 20 --rate-limit 3.0 --stats --sort-country --verbose

  # Custom URL with pagination
  scrape-insurance --url "https://custom-url" --max-pages 2

  # Headless mode disabled for debugging
  scrape-insurance --no-headless --max-pages 1 --verbose

  # Quick single-page scrape with summary
  scrape-insurance --max-pages 1 --stats
        """,
    )

    parser.add_argument(
        "--website",
        choices=["fitch", "franceassureurs", "abe", "hatvp"],
        default="fitch",
        help=(
            "Website to scrape: fitch (Fitch Ratings), "
            "franceassureurs (France Assureurs), abe (ABE Info Service), "
            "hatvp (HATVP) (default: fitch)"
        ),
    )

    parser.add_argument(
        "--url",
        type=str,
        help="URL to scrape (defaults to URL from corresponding XPATHs file)",
    )

    parser.add_argument(
        "--format",
        choices=["csv", "json"],
        default="csv",
        help="Output format: csv (spreadsheet), json (structured data) (default: csv)",
    )

    parser.add_argument(
        "--filename",
        type=str,
        help="Custom output filename (auto-generated if not specified)",
    )

    parser.add_argument(
        "--output-dir",
        type=str,
        default="output",
        help="Output directory (default: output)",
    )

    parser.add_argument(
        "--no-headless",
        action="store_true",
        help="Run browser in non-headless mode (visible browser window)",
    )

    parser.add_argument(
        "--timeout",
        type=int,
        default=10,
        help="WebDriver timeout in seconds (default: 10)",
    )

    parser.add_argument(
        "--rate-limit",
        type=float,
        default=2.0,
        help="Minimum interval between requests in seconds (default: 2.0)",
    )

    parser.add_argument(
        "--max-pages",
        type=int,
        default=10,
        help="Maximum number of pages to scrape (default: 10)",
    )

    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Enable verbose logging",
    )

    parser.add_argument(
        "--stats",
        action="store_true",
        help="Include summary statistics with the exported data",
    )

    parser.add_argument(
        "--sort-country",
        action="store_true",
        help="Group results by country and sort alphabetically within each country",
    )

    parser.add_argument(
        "--version",
        action="version",
        version="Insurance Scraper 0.1.0",
    )

    return parser


def get_default_url(website: str) -> str:
    """Get the default URL from the appropriate XPATHs file.

    Args:
        website: Website to get URL for ('fitch', 'franceassureurs', 'abe', or 'hatvp')

    Returns:
        Default URL string

    Raises:
        FileNotFoundError: If XPATHs file is not found
        ValueError: If URL is not found in the file
    """
    if website == "fitch":
        xpaths_file = Path("XPATHs_fitch.md")
        url_prefix = "URL to scrape :"
    elif website == "franceassureurs":
        xpaths_file = Path("XPATHs_franceassureurs.md")
        url_prefix = "URL :"
    elif website == "abe":
        xpaths_file = Path("XPATHs_ABE.md")
        url_prefix = "URL :"
    elif website == "hatvp":
        xpaths_file = Path("XPATHs_hatvp.md")
        url_prefix = "URL :"
    else:
        raise ValueError(f"Unknown website: {website}")

    if not xpaths_file.exists():
        raise FileNotFoundError(
            f"{xpaths_file} file not found. Please ensure you're running "
            "from the project root directory."
        )

    try:
        content = xpaths_file.read_text(encoding="utf-8")
        for line in content.split("\n"):
            if line.startswith(url_prefix):
                return line.split(":", 1)[1].strip()

        raise ValueError(f"No URL found in {xpaths_file} file")

    except Exception as e:
        raise ValueError(f"Error reading {xpaths_file} file: {e}") from e


def main() -> int:
    """Main CLI entry point.

    Returns:
        Exit code (0 for success, 1 for error)
    """
    parser = create_parser()
    args = parser.parse_args()

    # Set up logging
    setup_logging(args.verbose)
    logger = logging.getLogger(__name__)

    try:
        # Determine URL to scrape
        if args.url:
            url = args.url
            logger.info(f"Using provided URL: {url}")
        else:
            url = get_default_url(args.website)
            logger.info(
                f"Using default URL from XPATHs_{args.website}.md: {url[:100]}..."
            )

        # Configure scraper parameters
        headless = not args.no_headless

        # Scrape the data based on selected website
        logger.info(f"Starting scraping process for {args.website}...")

        if args.website == "fitch":
            logger.info(
                f"Fitch scraper configuration: headless={headless}, "
                f"timeout={args.timeout}s, rate_limit={args.rate_limit}s, "
                f"max_pages={args.max_pages}"
            )
            entities_data = scrape_fitch_insurance_entities(
                url=url,
                headless=headless,
                timeout=args.timeout,
                rate_limit=args.rate_limit,
                max_pages=args.max_pages,
            )
        elif args.website == "franceassureurs":
            logger.info(
                f"France Assureurs scraper configuration: headless={headless}, "
                f"timeout={args.timeout}s, rate_limit={args.rate_limit}s"
            )
            entities_data = scrape_france_assureurs_entities(
                url=url,
                headless=headless,
                timeout=args.timeout,
                rate_limit=args.rate_limit,
            )
        elif args.website == "abe":
            logger.info(
                f"ABE scraper configuration: headless={headless}, "
                f"timeout={args.timeout}s, rate_limit={args.rate_limit}s, "
                f"max_pages={args.max_pages}"
            )
            entities_data = scrape_abe_entities(
                url=url,
                headless=headless,
                timeout=args.timeout,
                rate_limit=args.rate_limit,
                max_pages=args.max_pages,
            )
        elif args.website == "hatvp":
            logger.info(
                f"HATVP scraper configuration: headless={headless}, "
                f"timeout={args.timeout}s, rate_limit={args.rate_limit}s"
            )
            entities_data = scrape_hatvp_entities(
                url=url,
                headless=headless,
                timeout=args.timeout,
                rate_limit=args.rate_limit,
            )
        else:
            raise ValueError(f"Unknown website: {args.website}")

        if not entities_data:
            logger.warning(
                "No entities were scraped. Please check the URL and page structure."
            )
            return 1

        logger.info(f"Successfully scraped {len(entities_data)} entities")

        # Export the data
        logger.info(f"Exporting data in {args.format} format...")
        output_path = export_data(
            data=entities_data,
            output_format=args.format,
            output_dir=args.output_dir,
            filename=args.filename,
            include_stats=getattr(args, "stats", False),
            website=args.website,
            sort_country=getattr(args, "sort_country", False),
        )

        logger.info(f"Data exported successfully to: {output_path}")

        return 0

    except KeyboardInterrupt:
        logger.info("Scraping interrupted by user")
        return 1

    except Exception as e:
        logger.error(f"Error during scraping: {e}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
