URL : https://www.abe-infoservice.fr/fr/liste-noire?blacklist_title=&blacklist_denomination_value=&blacklist_category_target_id%5B5417015%5D=5417015&blacklist_date_added_value_op=%3C&blacklist_date_added_value%5Bvalue%5D=&blacklist_date_added_value%5Bmin%5D=&blacklist_date_added_value%5Bmax%5D=&page=N

XPATH Table row : //*[@id="block-bdf-abeis-content"]/div/div/div/div[3]/div[2]/table/tbody/tr[X]
XPATH Table Cell : //*[@id="block-bdf-abeis-content"]/div/div/div/div[3]/div[2]/table/tbody/tr[X]/td[Y]
XPATH Url / mail name : //*[@id="block-bdf-abeis-content"]/div/div/div/div[3]/div[2]/table/tbody/tr[1]/td[1]/div/div
XPATH Denomination : //*[@id="block-bdf-abeis-content"]/div/div/div/div[3]/div[2]/table/tbody/tr[1]/td[2]/div/div
XPATH Category : //*[@id="block-bdf-abeis-content"]/div/div/div/div[3]/div[2]/table/tbody/tr[1]/td[3]/div/div
XPATH Date added : //*[@id="block-bdf-abeis-content"]/div/div/div/div[3]/div[2]/table/tbody/tr[1]/td[4]/div/div
