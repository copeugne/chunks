"""Test suite for the insurance scraper."""
