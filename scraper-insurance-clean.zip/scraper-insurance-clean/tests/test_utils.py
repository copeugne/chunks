"""Tests for utility functions."""

import time
from unittest.mock import Mock

import pytest
from selenium.common.exceptions import WebDriverException

from insurance_scraper.utils import (
    RateLimiter,
    parse_sector_country,
    retry_on_failure,
    safe_get_attribute,
    safe_get_text,
    validate_url,
)


class TestRetryDecorator:
    """Test the retry decorator functionality."""

    def test_retry_success_on_first_attempt(self) -> None:
        """Test that function succeeds on first attempt."""

        @retry_on_failure(max_attempts=3, delay=0.1)
        def successful_function() -> str:
            return "success"

        result = successful_function()
        assert result == "success"

    def test_retry_success_after_failure(self) -> None:
        """Test that function succeeds after initial failures."""
        call_count = 0

        @retry_on_failure(max_attempts=3, delay=0.1)
        def failing_then_success() -> str:
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise WebDriverException("Test failure")
            return "success"

        result = failing_then_success()
        assert result == "success"
        assert call_count == 3

    def test_retry_exhausts_attempts(self) -> None:
        """Test that function fails after exhausting all attempts."""

        @retry_on_failure(max_attempts=2, delay=0.1)
        def always_fails() -> None:
            raise WebDriverException("Always fails")

        with pytest.raises(WebDriverException):
            always_fails()


class TestRateLimiter:
    """Test the rate limiter functionality."""

    def test_rate_limiter_initial_request(self) -> None:
        """Test that first request doesn't wait."""
        limiter = RateLimiter(min_interval=1.0)

        start_time = time.time()
        limiter.wait_if_needed()
        elapsed = time.time() - start_time

        # Should not wait on first request
        assert elapsed < 0.1

    def test_rate_limiter_enforces_interval(self) -> None:
        """Test that rate limiter enforces minimum interval."""
        limiter = RateLimiter(min_interval=0.2)

        # First request
        limiter.wait_if_needed()

        # Second request should wait
        start_time = time.time()
        limiter.wait_if_needed()
        elapsed = time.time() - start_time

        # Should have waited approximately the minimum interval
        assert elapsed >= 0.15  # Allow some tolerance


class TestSafeGetters:
    """Test safe getter utility functions."""

    def test_safe_get_text_with_valid_element(self) -> None:
        """Test safe_get_text with valid element."""
        mock_element = Mock()
        mock_element.text = "  Test Text  "

        result = safe_get_text(mock_element)
        assert result == "Test Text"

    def test_safe_get_text_with_none_element(self) -> None:
        """Test safe_get_text with None element."""
        result = safe_get_text(None, "default")
        assert result == "default"

    def test_safe_get_text_with_empty_text(self) -> None:
        """Test safe_get_text with empty text."""
        mock_element = Mock()
        mock_element.text = ""

        result = safe_get_text(mock_element, "default")
        assert result == "default"

    def test_safe_get_text_with_exception(self) -> None:
        """Test safe_get_text when element raises exception."""
        mock_element = Mock()
        mock_element.text = Mock()
        mock_element.text.strip.side_effect = Exception("Test error")

        result = safe_get_text(mock_element, "default")
        assert result == "default"

    def test_safe_get_attribute_with_valid_element(self) -> None:
        """Test safe_get_attribute with valid element."""
        mock_element = Mock()
        mock_element.get_attribute.return_value = "test-value"

        result = safe_get_attribute(mock_element, "href")
        assert result == "test-value"
        mock_element.get_attribute.assert_called_once_with("href")

    def test_safe_get_attribute_with_none_element(self) -> None:
        """Test safe_get_attribute with None element."""
        result = safe_get_attribute(None, "href", "default")
        assert result == "default"

    def test_safe_get_attribute_with_exception(self) -> None:
        """Test safe_get_attribute when element raises exception."""
        mock_element = Mock()
        mock_element.get_attribute.side_effect = Exception("Test error")

        result = safe_get_attribute(mock_element, "href", "default")
        assert result == "default"


class TestUrlValidation:
    """Test URL validation functionality."""

    def test_valid_fitch_url(self) -> None:
        """Test that valid Fitch URLs are accepted."""
        valid_url = "https://www.fitchratings.com/search/?expanded=entity&filter.sector=Insurance"
        assert validate_url(valid_url) is True

    def test_invalid_url_wrong_domain(self) -> None:
        """Test that URLs with wrong domain are rejected."""
        invalid_url = "https://www.example.com/some-page"
        assert validate_url(invalid_url) is False

    def test_invalid_url_no_protocol(self) -> None:
        """Test that URLs without protocol are rejected."""
        invalid_url = "www.fitchratings.com/search"
        assert validate_url(invalid_url) is False

    def test_invalid_url_empty_string(self) -> None:
        """Test that empty string is rejected."""
        assert validate_url("") is False

    def test_invalid_url_none(self) -> None:
        """Test that None is rejected."""
        assert validate_url(None) is False

    def test_invalid_url_too_short(self) -> None:
        """Test that very short URLs are rejected."""
        short_url = "https://fit.com"
        assert validate_url(short_url) is False


class TestParseSectorCountry:
    """Test the sector and country parsing functionality."""

    def test_parse_with_comma_separation(self) -> None:
        """Test parsing with comma separation."""
        sector, country = parse_sector_country("Insurance, United States")
        assert sector == "Insurance"
        assert country == "United States"

    def test_parse_with_dash_separation(self) -> None:
        """Test parsing with dash separation."""
        sector, country = parse_sector_country("Reinsurance - Germany")
        assert sector == "Reinsurance"
        assert country == "Germany"

    def test_parse_space_separated_multi_word_country(self) -> None:
        """Test parsing with space separation and multi-word country."""
        sector, country = parse_sector_country("Insurance United Kingdom")
        assert sector == "Insurance"
        assert country == "United Kingdom"

    def test_parse_space_separated_single_word_country(self) -> None:
        """Test parsing with space separation and single-word country."""
        sector, country = parse_sector_country("Insurance France")
        assert sector == "Insurance"
        assert country == "France"

    def test_parse_with_unknown_input(self) -> None:
        """Test parsing with unknown input."""
        sector, country = parse_sector_country("Unknown")
        assert sector == "Unknown"
        assert country == "Unknown"

    def test_parse_with_empty_input(self) -> None:
        """Test parsing with empty input."""
        sector, country = parse_sector_country("")
        assert sector == "Unknown"
        assert country == "Unknown"

    def test_parse_with_complex_sector(self) -> None:
        """Test parsing with complex sector description."""
        sector, country = parse_sector_country("Life & Health Insurance, Canada")
        assert sector == "Life & Health Insurance"
        assert country == "Canada"

    def test_parse_single_word_fallback(self) -> None:
        """Test parsing when only sector is available."""
        sector, country = parse_sector_country("Insurance")
        assert sector == "Insurance"
        assert country == "Unknown"
