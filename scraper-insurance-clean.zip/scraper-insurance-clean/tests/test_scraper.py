"""Tests for scraper functionality."""

from collections.abc import Generator
from unittest.mock import Mock, patch

import pytest
from selenium.common.exceptions import TimeoutException

from insurance_scraper.scraper import (
    FitchRatingsScraper,
    InsuranceEntity,
    scrape_fitch_insurance_entities,
)


class TestInsuranceEntity:
    """Test the InsuranceEntity data class."""

    def test_entity_creation(self) -> None:
        """Test creating an InsuranceEntity."""
        entity = InsuranceEntity(
            entity_name="Test Insurance",
            sector="Insurance",
            country="USA",
            url="https://example.com",
        )

        assert entity.entity_name == "Test Insurance"
        assert entity.sector == "Insurance"
        assert entity.country == "USA"
        assert entity.url == "https://example.com"

    def test_entity_creation_with_defaults(self) -> None:
        """Test creating an InsuranceEntity with default values."""
        entity = InsuranceEntity(
            entity_name="Test Insurance", sector="Insurance", country="USA"
        )

        assert entity.entity_name == "Test Insurance"
        assert entity.sector == "Insurance"
        assert entity.country == "USA"
        assert entity.url is None


class TestFitchRatingsScraper:
    """Test the FitchRatingsScraper class."""

    @pytest.fixture
    def mock_driver_setup(self) -> Generator[tuple[Mock, Mock], None, None]:
        """Mock the WebDriver setup to avoid actual browser initialization."""
        with (
            patch("insurance_scraper.scraper.ChromeDriverManager") as mock_manager,
            patch("insurance_scraper.scraper.webdriver.Chrome") as mock_chrome,
            patch("insurance_scraper.scraper.WebDriverWait") as mock_wait,
        ):
            mock_manager.return_value.install.return_value = "/fake/path/chromedriver"
            mock_driver = Mock()
            mock_chrome.return_value = mock_driver
            mock_wait_instance = Mock()
            mock_wait.return_value = mock_wait_instance

            yield mock_driver, mock_wait_instance

    def test_scraper_initialization(self) -> None:
        """Test scraper initialization with default parameters."""
        scraper = FitchRatingsScraper()

        assert scraper.headless is True
        assert scraper.timeout == 10
        assert scraper.rate_limiter is not None
        assert scraper.driver is None

    def test_scraper_initialization_with_params(self) -> None:
        """Test scraper initialization with custom parameters."""
        scraper = FitchRatingsScraper(headless=False, timeout=20, rate_limit=3.0)

        assert scraper.headless is False
        assert scraper.timeout == 20
        assert scraper.rate_limiter.min_interval == 3.0

    def test_invalid_url_validation(self) -> None:
        """Test that invalid URLs raise ValueError."""
        scraper = FitchRatingsScraper()

        with pytest.raises(ValueError, match="Invalid URL provided"):
            scraper.scrape_url("invalid-url")

        with pytest.raises(ValueError, match="Invalid URL provided"):
            scraper.scrape_url("https://example.com")

    @patch("insurance_scraper.scraper.validate_url")
    def test_driver_setup_called_when_needed(
        self, mock_validate: Mock, mock_driver_setup: tuple[Mock, Mock]
    ) -> None:
        """Test that driver setup is called when driver is None."""
        mock_validate.return_value = True
        _mock_driver, _mock_wait = mock_driver_setup

        scraper = FitchRatingsScraper()
        assert scraper.driver is None

        # Mock the extraction method to avoid complex DOM setup
        with patch.object(scraper, "_extract_entity_data", return_value=[]):
            scraper.scrape_url(
                "https://www.fitchratings.com/search/?filter.sector=Insurance"
            )

        # Driver should now be set
        assert scraper.driver is not None

    @patch("insurance_scraper.scraper.validate_url")
    @patch("insurance_scraper.scraper.time.sleep")  # Speed up tests
    def test_scrape_url_successful(
        self,
        _mock_sleep: Mock,
        mock_validate: Mock,
        mock_driver_setup: tuple[Mock, Mock],
    ) -> None:
        """Test successful URL scraping."""
        mock_validate.return_value = True
        _mock_driver, _mock_wait = mock_driver_setup

        # Setup mock entities
        mock_entities = [
            InsuranceEntity("Test Insurance", "Insurance", "USA", "https://example.com")
        ]

        scraper = FitchRatingsScraper()

        with patch.object(scraper, "_extract_entity_data", return_value=mock_entities):
            entities = scraper.scrape_url(
                "https://www.fitchratings.com/search/?filter.sector=Insurance"
            )

            assert len(entities) == 1
            assert entities[0].entity_name == "Test Insurance"

    def test_context_manager(self, mock_driver_setup: tuple[Mock, Mock]) -> None:
        """Test using scraper as context manager."""
        mock_driver, _mock_wait = mock_driver_setup

        with FitchRatingsScraper() as scraper:
            assert scraper.driver is not None

        # Driver should be cleaned up after context exit
        mock_driver.quit.assert_called_once()

    @patch("insurance_scraper.scraper.validate_url")
    def test_extraction_error_handling(
        self, mock_validate: Mock, mock_driver_setup: tuple[Mock, Mock]
    ) -> None:
        """Test error handling during data extraction."""
        mock_validate.return_value = True
        _mock_driver, _mock_wait = mock_driver_setup

        scraper = FitchRatingsScraper()

        # Mock extraction to raise an exception
        with (
            patch.object(
                scraper,
                "_extract_entity_data",
                side_effect=TimeoutException("Test timeout"),
            ),
            pytest.raises(TimeoutException),
        ):
            scraper.scrape_url(
                "https://www.fitchratings.com/search/?filter.sector=Insurance"
            )

    def test_xpath_selectors_defined(self) -> None:
        """Test that XPath selectors are properly defined."""
        scraper = FitchRatingsScraper()

        assert scraper.entity_name_xpath_template is not None
        assert scraper.sector_country_xpath_template is not None
        assert "main-content" in scraper.entity_name_xpath_template
        assert "main-content" in scraper.sector_country_xpath_template
        assert "[N]" in scraper.entity_name_xpath_template
        assert "[N]" in scraper.sector_country_xpath_template


class TestScrapeFunctionIntegration:
    """Test the convenience function for scraping."""

    @patch("insurance_scraper.scraper.FitchRatingsScraper")
    def test_scrape_fitch_insurance_entities(self, mock_scraper_class: Mock) -> None:
        """Test the convenience function for scraping entities."""
        # Setup mock scraper instance
        mock_scraper = Mock()
        mock_scraper.__enter__ = Mock(return_value=mock_scraper)
        mock_scraper.__exit__ = Mock(return_value=None)
        mock_scraper_class.return_value = mock_scraper

        # Setup mock entities
        mock_entities = [
            InsuranceEntity("Test Insurance", "Insurance", "USA", "https://example.com")
        ]
        mock_scraper.scrape_url.return_value = mock_entities

        # Call the convenience function
        url = "https://www.fitchratings.com/search/?filter.sector=Insurance"
        result = scrape_fitch_insurance_entities(url, headless=True)

        # Verify the result is a list of dictionaries
        assert isinstance(result, list)
        assert len(result) == 1
        assert isinstance(result[0], dict)
        assert result[0]["entity_name"] == "Test Insurance"

        # Verify scraper was called correctly
        mock_scraper_class.assert_called_once_with(
            headless=True, timeout=10, rate_limit=2.0, max_pages=10
        )
        mock_scraper.scrape_url.assert_called_once_with(url)
