"""Tests for data exporter functionality."""

import csv
import json
from collections.abc import Generator
from pathlib import Path
from tempfile import TemporaryDirectory

import pytest

from insurance_scraper.exporter import DataExporter, export_data


class TestDataExporter:
    """Test the DataExporter class."""

    @pytest.fixture
    def sample_data(self) -> list[dict[str, object]]:
        """Sample insurance entity data for testing."""
        return [
            {
                "entity_name": "Test Insurance Co.",
                "sector": "Insurance",
                "country": "United States",
                "url": "https://www.fitchratings.com/entity/test-insurance-co",
            },
            {
                "entity_name": "Global Re Ltd",
                "sector": "Reinsurance",
                "country": "United Kingdom",
                "url": "https://www.fitchratings.com/entity/global-re-ltd",
            },
        ]

    @pytest.fixture
    def temp_exporter(self) -> Generator[DataExporter, None, None]:
        """Create a temporary exporter with temp directory."""
        with TemporaryDirectory() as temp_dir:
            exporter = DataExporter(temp_dir)
            yield exporter

    def test_csv_export(
        self, temp_exporter: DataExporter, sample_data: list[dict[str, object]]
    ) -> None:
        """Test CSV export functionality."""
        output_path = temp_exporter.export_to_csv(sample_data, "test_output.csv")

        assert output_path.exists()
        assert output_path.suffix == ".csv"

        # Verify CSV content
        with output_path.open(encoding="utf-8") as csvfile:
            reader = csv.DictReader(csvfile)
            rows = list(reader)

            assert len(rows) == 2
            assert rows[0]["entity_name"] == "Test Insurance Co."
            assert rows[1]["entity_name"] == "Global Re Ltd"

    def test_json_export(
        self, temp_exporter: DataExporter, sample_data: list[dict[str, object]]
    ) -> None:
        """Test JSON export functionality."""
        output_path = temp_exporter.export_to_json(sample_data, "test_output.json")

        assert output_path.exists()
        assert output_path.suffix == ".json"

        # Verify JSON content
        with output_path.open(encoding="utf-8") as jsonfile:
            data = json.load(jsonfile)

            assert "metadata" in data
            assert "entities" in data
            assert data["metadata"]["total_entities"] == 2
            assert len(data["entities"]) == 2
            assert data["entities"][0]["entity_name"] == "Test Insurance Co."

    def test_summary_export(
        self, temp_exporter: DataExporter, sample_data: list[dict[str, object]]
    ) -> None:
        """Test summary export functionality."""
        output_path = temp_exporter.export_summary(sample_data, "test_summary.txt")

        assert output_path.exists()
        assert output_path.suffix == ".txt"

        # Verify summary content
        with output_path.open(encoding="utf-8") as summaryfile:
            content = summaryfile.read()

            assert "Total Entities: 2" in content
            assert "United States" in content
            assert "United Kingdom" in content

    def test_empty_data_raises_error(self, temp_exporter: DataExporter) -> None:
        """Test that empty data raises ValueError."""
        empty_data: list[dict[str, object]] = []

        with pytest.raises(ValueError, match="Cannot export empty data"):
            temp_exporter.export_to_csv(empty_data)

        with pytest.raises(ValueError, match="Cannot export empty data"):
            temp_exporter.export_to_json(empty_data)

        with pytest.raises(ValueError, match="Cannot generate summary"):
            temp_exporter.export_summary(empty_data)

    def test_filename_generation(
        self, temp_exporter: DataExporter, sample_data: list[dict[str, object]]
    ) -> None:
        """Test automatic filename generation."""
        output_path = temp_exporter.export_to_csv(sample_data)

        # Should generate filename with timestamp
        assert "fitch_entities_" in output_path.name
        assert output_path.suffix == ".csv"

    def test_output_directory_creation(
        self, sample_data: list[dict[str, object]]
    ) -> None:
        """Test that output directory is created if it doesn't exist."""
        with TemporaryDirectory() as temp_dir:
            output_dir = Path(temp_dir) / "new_output_dir"
            exporter = DataExporter(str(output_dir))

            # Directory should be created
            assert output_dir.exists()

            # Should be able to export
            output_path = exporter.export_to_csv(sample_data, "test.csv")
            assert output_path.exists()


class TestExportDataFunction:
    """Test the convenience export_data function."""

    @pytest.fixture
    def sample_data(self) -> list[dict[str, object]]:
        """Sample insurance entity data for testing."""
        return [
            {
                "entity_name": "Test Insurance Co.",
                "sector": "Insurance",
                "country": "United States",
                "url": "https://www.fitchratings.com/entity/test-insurance-co",
            }
        ]

    def test_export_data_csv(self, sample_data: list[dict[str, object]]) -> None:
        """Test export_data function with CSV format."""
        with TemporaryDirectory() as temp_dir:
            output_path = export_data(
                sample_data,
                output_format="csv",
                output_dir=temp_dir,
                filename="test.csv",
            )

            assert output_path.exists()
            assert output_path.suffix == ".csv"

    def test_export_data_json(self, sample_data: list[dict[str, object]]) -> None:
        """Test export_data function with JSON format."""
        with TemporaryDirectory() as temp_dir:
            output_path = export_data(
                sample_data,
                output_format="json",
                output_dir=temp_dir,
                filename="test.json",
            )

            assert output_path.exists()
            assert output_path.suffix == ".json"

    def test_export_data_invalid_format(
        self, sample_data: list[dict[str, object]]
    ) -> None:
        """Test export_data function with invalid format."""
        with (
            TemporaryDirectory() as temp_dir,
            pytest.raises(ValueError, match="Unsupported output format"),
        ):
            export_data(sample_data, output_format="xml", output_dir=temp_dir)
