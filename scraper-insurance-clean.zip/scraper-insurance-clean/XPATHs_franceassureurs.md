URL : https://www.franceassureurs.fr/qui-sommes-nous/nos-adherents/

XPATH insurance name : //*[@id="who-block-adherents-fa-b1"]/div/div[2]/div/ul/li/div[1]/div[1]
XPATH Group name :     //*[@id="who-block-adherents-fa-b1"]/div/div[2]/div/ul/li/div[1]/div[2]
XPATH street : //*[@id="who-block-adherents-fa-b1"]/div/div[2]/div/ul/li/div[1]/div[3]
XPATH postal code and city : //*[@id="who-block-adherents-fa-b1"]/div/div[2]/div/ul/li/div[1]/div[4]
XPATH url : //*[@id="who-block-adherents-fa-b1"]/div/div[2]/div/ul/li/div[1]/div[5]
XPATH phone number : //*[@id="who-block-adherents-fa-b1"]/div/div[2]/div/ul/li/div[1]/div[6]
